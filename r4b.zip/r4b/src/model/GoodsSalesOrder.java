package model;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataSelector;

public class GoodsSalesOrder {
	// ATTRIBUTES FOR TABLE goods_sales_orders_header:
		private int orderId;
		private int companyId;
		private int businessPartnerId;
		private Date orderDate;
		
		// ATTRIBUTES FOR VIEW v_goods_sales_orders_header:
		private String companyName;
		private String businessPartnerName;
		
		// ATTRIBUTES FOR TABLE goods_sales_order_lines:
		
		
		// ATTRIBUTES FOR VIEW v_goods_sales_orders_lines:
		
		
		public GoodsSalesOrder() {
			
		}
		
		public GoodsSalesOrder(int orderId, int companyId, int businessPartnerId, Date orderDate) {
			super();
			this.orderId = orderId;
			this.companyId = companyId;
			this.businessPartnerId = businessPartnerId;
			this.orderDate = orderDate;
		}

		public GoodsSalesOrder(int orderId, String companyName, String businessPartnerName, Date orderDate) {
			super();
			this.orderId = orderId;
			this.companyName = companyName;
			this.businessPartnerName = businessPartnerName;
			this.orderDate = orderDate;
		}
		
		public int getOrderId() {
			return orderId;
		}

		public void setOrderId(int orderId) {
			this.orderId = orderId;
		}

		public int getCompanyId() {
			return companyId;
		}

		public void setCompanyId(int companyId) {
			this.companyId = companyId;
		}

		public int getBusinessPartnerId() {
			return businessPartnerId;
		}

		public void setBusinessPartnerId(int businessPartnerId) {
			this.businessPartnerId = businessPartnerId;
		}

		public Date getOrderDate() {
			return orderDate;
		}

		public void setOrderDate(Date orderDate) {
			this.orderDate = orderDate;
		}

		public String getCompanyName() {
			return companyName;
		}

		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}

		public String getBusinessPartnerName() {
			return businessPartnerName;
		}

		public void setBusinessPartnerName(String businessPartnerName) {
			this.businessPartnerName = businessPartnerName;
		}

		// SHOW goods sales orders IN TABLE OF VIEW GoodsSalesOrders.fxml:
		public ObservableList<GoodsSalesOrder> getGoodsSalesOrders() {
			ObservableList<GoodsSalesOrder> obs = FXCollections.observableArrayList();

			try {
				// MAKE OBJECT ResultSet AND EXECUTE QUERY:
				ResultSet rs = DataSelector.selectQuery("select *  from v_goods_sales_orders_header");

				// RESULTS:
				while (rs.next()) {
					// GET DATA
					orderId = rs.getInt(1);
					companyName = rs.getString(2);
					businessPartnerName = rs.getString(3);
					orderDate = rs.getDate(4);

					// MAKE OBJECT GoodsSalesOrder
					GoodsSalesOrder gso = new GoodsSalesOrder(orderId, companyName, businessPartnerName, orderDate);

					obs.add(gso);
				}

				// CLOSE CONNECTION:
				ConnectionDb.closeConnection();
			} catch (SQLException ex) {
				// ex.printStackTrace();
				
				AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los datos en la tabla.");
			}

			// RETURN ObservableList:
			return obs;
		}
}
