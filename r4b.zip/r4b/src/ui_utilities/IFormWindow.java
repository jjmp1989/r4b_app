package ui_utilities;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

public interface IFormWindow {
	public static void gpNewBottomButtonHoverIn(Button b) {
		b.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: lime; -fx-background-color: white;");

		b.setTextFill(Color.LIME);
	}
	
	public static void gpNewBottomButtonHoverOut(Button b) {
		b.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: forestgreen; -fx-background-color: white;");

		b.setTextFill(Color.FORESTGREEN);
	}
	
	public static void gpNewBottomButtonPressed(Button b) {
		b.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: darkgreen; -fx-background-color: white;");
		
		b.setTextFill(Color.DARKGREEN);
	}
	
	public static void gpNewBottomButtonReleased(Button b) {
		b.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: forestgreen; -fx-background-color: white;");
		
		b.setTextFill(Color.FORESTGREEN);
	}
	
	public static void gpModifyBottomButtonHoverIn(Button b) {
		b.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: fuchsia; -fx-background-color: white;");

		b.setTextFill(Color.FUCHSIA);
	}
	
	public static void gpModifyBottomButtonHoverOut(Button b) {
		b.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: blueviolet; -fx-background-color: white;");

		b.setTextFill(Color.BLUEVIOLET);
	}
	
	public static void gpModifyBottomButtonPressed(Button b) {
		b.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: indigo; -fx-background-color: white;");
		
		b.setTextFill(Color.INDIGO);
	}
	
	public static void gbModifyBottomButtonReleased(Button b) {
		b.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: blueviolet; -fx-background-color: white;");
		
		b.setTextFill(Color.BLUEVIOLET);
	}
	
	// TO FILTER STRING IN CB:
	public static void filterString(String filter, ComboBox<String> cb, ObservableList<String> olInitial) {
		ObservableList<String> olFiltered = FXCollections.observableArrayList();

		/*
		 * if(!olFilter.isEmpty()) { olFilter.clear(); }
		 */

		if (filter.isEmpty()) {
			cb.setItems(olInitial);
		} else {
			// System.out.println(filter);

			if (cb.getSelectionModel().getSelectedItem() != null) {
				// System.out.println(filter);

				filter = cb.getEditor().getText();

				// System.out.println(filter);

				cb.getSelectionModel().select(null);

				cb.getEditor().setText(filter);
			}

			for (String item : olInitial) {
				if (item.toLowerCase().contains(filter.toLowerCase())) {
					olFiltered.add(item);
				}

				cb.setItems(olFiltered);
			}
		}
	}

	// TO CHECK SERVICE TYPE CB IN NEW FORM:
	public static boolean checkNewCbIsSelected(ComboBox<String> cb, ObservableList<String> olItems) {
		boolean cbIsSelected = false;

		for (String item : olItems) {
			// TEST:
			// System.out.println(cbServiceType.getSelectionModel().getSelectedItem() +" - "
			// +item);

			if (item.equals(cb.getSelectionModel().getSelectedItem())) {
				cbIsSelected = true;

				// System.out.println(stOk);

				cb.setStyle("-fx-border-color: green;");

				// cbServiceType.getItems().remove(cbServiceType.getSelectionModel().getSelectedItem());

				return cbIsSelected;
			} else {
				cbIsSelected = false;

				cb.setStyle("-fx-border-color: red;");
			}
		}
		// TEST:
		// System.out.println(stOk);
		// System.out.println("-----------------------------");

		return cbIsSelected;
	}
	
	// TO CHECK SERVICE TYPE CB IN MODIFY FORM:
	public static boolean checkModifyCbIsSelected(ComboBox<String> cb, ObservableList<String> olItems) {
		boolean cbIsSelected = false;

		for (String item : olItems) {
			if (item.equals(cb.getSelectionModel().getSelectedItem())) {
				cbIsSelected = true;

				cb.setStyle("-fx-border-color: blueviolet;");

				return cbIsSelected;
			} else {
				cbIsSelected = false;

				cb.setStyle("-fx-border-color: red;");
			}
		}

		return cbIsSelected;
	}
	
	// CHECK IF IT'S NUMBER OR EMPTY TEXT FIELD:
	public static boolean checkNumberTextField(TextField tf) {
		if(tf.getText().isEmpty() || !isNumeric(tf.getText())) {
			return false;
		} else {
			return true;
		}
	}

	// METHOD TO VERIFY NUMBER:
	public static boolean isNumeric(String s) {
		try {
			Float.parseFloat(s);

			return true;
		} catch (NumberFormatException nfe) {
			return false;
		}
	}
}
