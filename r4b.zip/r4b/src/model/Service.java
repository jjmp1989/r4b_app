package model;

import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataInsertion;
import r4b_ddbb_management.DataSelector;
import r4b_ddbb_management.DataUpdate;

public class Service {
	// ATTRIBUTES TABLE services:
	private int id;
	private int serviceTypeId;
	private int measureId;
	private String name;
	private String description;
	private Float uPrice;

	// ATTRIBUTES VIEW v_services:
	private String serviceTypeName;
	private String measureName;

	// AFFECTED ROWS NUMBER:
	private int rows = 0;

	public Service() {

	}

	// CONSTRUCTOR FOR TABLE services:
	public Service(int id, int serviceTypeId, int measureId, String name, String description, Float uPrice) {
		this.id = id;
		this.serviceTypeId = serviceTypeId;
		this.measureId = measureId;
		this.name = name;
		this.description = description;
		this.uPrice = uPrice;
	}

	// CONSTRUCTOR FOR VIEW v_services:
	public Service(int id, String name, String description, String serviceTypeName, String measureName, Float uPrice) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.serviceTypeName = serviceTypeName;
		this.measureName = measureName;
		this.uPrice = uPrice;
	}

	// CONSTRUCTOR TO INSERT services:
	public Service(int serviceTypeId, int measureId, String name, String description, Float uPrice) {
		this.serviceTypeId = serviceTypeId;
		this.measureId = measureId;
		this.name = name;
		this.description = description;
		this.uPrice = uPrice;
	}

	// GETTERS AND SETTERS:

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getServiceTypeId() {
		return serviceTypeId;
	}

	public void setServiceTypeId(int serviceTypeId) {
		this.serviceTypeId = serviceTypeId;
	}

	public int getMeasureId() {
		return measureId;
	}

	public void setMeasureId(int measureId) {
		this.measureId = measureId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public float getUPrice() {
		return uPrice;
	}

	public void setUPrice(float uPrice) {
		this.uPrice = uPrice;
	}

	public String getServiceTypeName() {
		return serviceTypeName;
	}

	public void setServiceTypeName(String serviceTypeName) {
		this.serviceTypeName = serviceTypeName;
	}

	public String getMeasureName() {
		return measureName;
	}

	public void setMeasureName(String measureName) {
		this.measureName = measureName;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	// ------------------------------------------------------------------------------

	// SHOW companies IN TABLE OF VIEW Companies.fxml:
	public ObservableList<Service> getServices() {
		ObservableList<Service> obs = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQuery("select * from v_services;");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
				name = rs.getString(2);
				description = rs.getString(3);
				serviceTypeName = rs.getString(4);
				measureName = rs.getString(5);
				uPrice = rs.getFloat(6);

				// MAKE OBJECT Company
				Service s = new Service(id, name, description, serviceTypeName, measureName, uPrice);

				obs.add(s);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� al mostrar los servicios en la tabla.");
		}

		// RETURN ObservableList:
		return obs;
	}

	// ---------------------------------------------------------------------------------------------

	// GET SERVICE NAME:
	public ObservableList<String> getServiceName() {
		ObservableList<String> olService = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("SELECT `name` FROM `services` ORDER BY `id`");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				name = rs.getString(1);

				olService.add(name);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� al obtener los servicios.");
		}

		// RETURN ObservableList:
		return olService;
	}
	// ----------------------------------------------------------------------------------------

	// GET SERVICE ID:
	public int getServiceIdWithName() {
		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQueryWithRestrictionString("call get_service_id_with_name(?)", getName());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al obtener el id del servicio.");
		}

		// RETURN SERVICE ID:
		return id;
	}

	// ----------------------------------------------------------------------------------------

	// INSERT SERVICE:
	public boolean insertService() {
		try {
			rows = DataInsertion.insertServiceData(getServiceTypeId(), getMeasureId(), getName(), getDescription(),
					getUPrice());

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al insertar un servicio.");
		}

		return false;
	}

	// -------------------------------------------------------------------------------------

	// UPDATE SERVICE:
	public boolean updateService() {
		try {
			rows = DataUpdate.updateHeaderData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar el servicio.");
		}

		return false;
	}
}
