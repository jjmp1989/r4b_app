package r4b_ddbb_management;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JOptionPane;

public class DatabaseSecurity {
	private final String KEY_PATH = "resources/temp/key.txt";
	private final String VALUE_PATH = "resources/temp/value.txt";

	// ENCRYPT:
	public String encrypt(String s) {
		// FINAL VARIABLES FOR ALPHABET 
		final int ALPHABET_SIZE = 26, START_LOWERCASE = 97, START_UPPERCASE = 65;
		// STRING ENCRYPTED:
		String result = "";

		for (int x = 0; x < s.length(); x++) {
			char currentChar = s.charAt(x);

			if (!Character.isLetter(currentChar)) {
				if (Character.isDigit(currentChar)) {
					int newNumber;

					if (Integer.parseInt(String.valueOf(currentChar)) == 9) {
						newNumber = 0;

						result += newNumber;

						continue;
					} else {
						newNumber = Integer.parseInt(String.valueOf(currentChar)) + 1;

						result += newNumber;

						continue;
					}
				}

				result += currentChar;
				continue;
			}

			int characterCode = (int) currentChar;
			boolean isUpperCase = Character.isUpperCase(currentChar);

			int newPosition = ((characterCode - (isUpperCase ? START_UPPERCASE : START_LOWERCASE)) + 5) % ALPHABET_SIZE;
			if (newPosition < 0)
				newPosition += ALPHABET_SIZE;
			int newPositionCodeCharacter = (isUpperCase ? START_UPPERCASE : START_LOWERCASE) + newPosition;
			result += Character.toString((char) newPositionCodeCharacter);
		}
		
		return result;
	}

	// DECRYPT:
	public String decrypt(String s) {
		final int ALPHABET_SIZE = 26, START_LOWERCASE = 97, START_UPPERCASE = 65;
		String result = "";
		for (int x = 0; x < s.length(); x++) {
			char currentChar = s.charAt(x);

			if (!Character.isLetter(currentChar)) {
				if (Character.isDigit(currentChar)) {
					int newNumber;

					if (Integer.parseInt(String.valueOf(currentChar)) == 0) {
						newNumber = 9;

						result += newNumber;

						continue;
					} else {
						newNumber = Integer.parseInt(String.valueOf(currentChar)) - 1;

						result += newNumber;

						continue;
					}
				}

				result += currentChar;
				continue;
			}

			int characterCode = (int) currentChar;
			boolean isUpperCase = Character.isUpperCase(currentChar);

			int newPosition = ((characterCode - (isUpperCase ? START_UPPERCASE : START_LOWERCASE)) - 5) % ALPHABET_SIZE;
			if (newPosition < 0)
				newPosition += ALPHABET_SIZE;
			int newPositionCodeCharacter = (isUpperCase ? START_UPPERCASE : START_LOWERCASE) + newPosition;
			result += Character.toString((char) newPositionCodeCharacter);
		}
		return result;
	}

	// MAKE FILES FOR CREDENTIALS:
	public void makeSecurityFiles(String key, String value) {
		try {
			File keyFile = new File(KEY_PATH);
			File valueFile = new File(VALUE_PATH);

			if (!keyFile.exists()) {
				keyFile.createNewFile();
			}

			if (!valueFile.exists()) {
				valueFile.createNewFile();
			}

			writeInFile(encrypt(key), keyFile);
			writeInFile(encrypt(value), valueFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// DELETE FILES FOR CREDENTIALS:
	public void deleteSecurityFiles() {
		File keyFile = new File(KEY_PATH);
		File valueFile = new File(VALUE_PATH);
		
		if (!keyFile.exists()) {
			JOptionPane.showConfirmDialog(null, "El archivo data no existe.");
		} else {
			keyFile.delete();
		}
		
		if (!valueFile.exists()) {
			JOptionPane.showConfirmDialog(null, "El archivo data no existe.");
		} else {
			valueFile.delete();
		}
	}

	// WRITE IN FILE:
	public void writeInFile(String s, File file) {
		FileWriter fw = null;

		try {
			fw = new FileWriter(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		BufferedWriter bw = new BufferedWriter(fw);

		try {
			bw.write(s);
			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// READ FILE FOR KEY:
	public String readKeyFile() {
		String result = "";

		try {
			FileReader fr = new FileReader(KEY_PATH);
			String s = "";
			int c = 0;

			while (c != -1) {
				c = fr.read();

				char letra = (char) c;

				s += letra;
			}

			result = s.substring(0, s.length() - 1);

			fr.close();
		} catch (IOException e) {
			JOptionPane.showInternalMessageDialog(null, "No se ha encontrado el archivo");
		}

		return result;
	}

	// READ FILE FOR VALUE:
	public String readValueFile() {
		String result = "";

		try {
			FileReader fr = new FileReader(VALUE_PATH);
			String s = "";
			int c = 0;

			while (c != -1) {
				c = fr.read();

				char letra = (char) c;

				s += letra;
			}

			result = s.substring(0, s.length() - 1);

			fr.close();
		} catch (IOException e) {
			JOptionPane.showInternalMessageDialog(null, "No se ha encontrado el archivo");
		}

		return result;
	}

	// GET CREADENTIALS:
	public String[] getCredentials() {
		String[] credentials = { decrypt(readKeyFile()), decrypt(readValueFile()) };

		return credentials;
	}
}
