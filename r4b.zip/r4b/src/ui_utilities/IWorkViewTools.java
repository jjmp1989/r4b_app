package ui_utilities;

import java.io.IOException;

import alert_messages.AlertMessage;
import controller.ModifyBusinessPartnerController;
import controller.ModifyCompanyController;
import controller.ModifyMeasureController;
import controller.ModifyServiceController;
import controller.ModifyServiceTypeController;
import controller.ModifyServicesSalesOrderController;
import controller.ModifyServicesSalesOutputController;
import controller.ServicesSalesOrderViewController;
import controller.ServicesSalesOutputViewController;
import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import model.BusinessPartner;
import model.Company;
import model.Measure;
import model.Service;
import model.ServiceType;
import model.ServicesSalesOrder;
import model.ServicesSalesOutput;

public interface IWorkViewTools {
	public static void changeRoot(Event e, BorderPane bpWorkView, Button button, FXMLLoader loader) {
		if (e.getSource() == button) {
			try {
				Parent root = loader.load();

				bpWorkView.setCenter(root);
			} catch (IOException ioe) {
				// ioe.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada. Existe un problema con el archivo fxml.");
			} catch (Exception ex) {
				// ex.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada.");
			}
		}
	}

	public static void changeRootToView(Event e, BorderPane bpWorkViewCenter, Button button, FXMLLoader loader,
			Object o) {
		if (e.getSource() == button) {
			try {
				Parent root = loader.load();

				BorderPane bpWorkView = (BorderPane) bpWorkViewCenter.getParent();

				bpWorkView.setTop(null);
				bpWorkView.setLeft(null);
				bpWorkView.setCenter(root);

				if (o.getClass().getName().equals(ServicesSalesOrder.class.getName())) {
					ServicesSalesOrderViewController ssOrderViewController = loader.getController();

					ssOrderViewController.initAttributesHeader((ServicesSalesOrder) o);
				} else if (o.getClass().getName().equals(ServicesSalesOutput.class.getName())) {
					ServicesSalesOutputViewController ssOutputViewController = loader.getController();

					ssOutputViewController.initAttributesHeader((ServicesSalesOutput) o);
				}
			} catch (IOException ioe) {
				// ioe.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada. Existe un problema con el archivo fxml.");
			} catch (Exception ex) {
				// ex.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada.");
			}
		}
	}

	public static void changeRootToList(Event e, BorderPane bpWorkViewCenter, Button button, FXMLLoader loader) {
		if (e.getSource() == button) {
			try {
				Parent root = loader.load();

				BorderPane bpWorkView = (BorderPane) bpWorkViewCenter.getParent();

				bpWorkView.setCenter(null);

				bpWorkView.setCenter(root);
			} catch (IOException ioe) {
				// ioe.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada. Existe un problema con el archivo fxml.");
			} catch (Exception ex) {
				// ex.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada.");
			}
		}
	}

	public static void openWindowForNewRecord(Event e, Button button, FXMLLoader loader) {
		if (e.getSource() == button) {
			try {
				Parent root = loader.load();
				Scene s = new Scene(root);
				Stage stage = new Stage();

				stage.initStyle(StageStyle.UNDECORATED);
				stage.initStyle(StageStyle.TRANSPARENT);

				s.setFill(Color.TRANSPARENT);

				stage.setScene(s);
				stage.show();
			} catch (IOException ioe) {
				// ioe.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada. Existe un problema con el archivo fxml.");
			} catch (Exception ex) {
				// ex.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada.");
			}
		}
	}

	public static void openWindowToModifyRecord(Event e, Button button, FXMLLoader loader, Object o) {
		if (e.getSource() == button) {
			String className = o.getClass().getName();

			try {
				Parent root = loader.load();
				Scene s = new Scene(root);
				Stage stage = new Stage();

				if (className.equals(BusinessPartner.class.getName())) {
					ModifyBusinessPartnerController bp = loader.getController();

					bp.initAttributesBusinessPartner((BusinessPartner) o);
				} else if (className.equals(Company.class.getName())) {
					ModifyCompanyController mcc = loader.getController();

					mcc.initAttributesCompany((Company) o);
				} else if (className.equals(Measure.class.getName())) {
					ModifyMeasureController mmc = loader.getController();

					mmc.initAttributesMeasure((Measure) o);
				} else if (className.equals(ServiceType.class.getName())) {
					ModifyServiceTypeController mstc = loader.getController();

					mstc.initAttributesServiceType((ServiceType) o);
				} else if (className.equals(Service.class.getName())) {
					ModifyServiceController msc = loader.getController();

					msc.initAttributesService((Service) o);
				} else if (className.equals(ServicesSalesOrder.class.getName())) {
					ModifyServicesSalesOrderController mssOrder = loader.getController();

					mssOrder.initAttributes((ServicesSalesOrder) o);
				} else if (className.equals(ServicesSalesOutput.class.getName())) {
					ModifyServicesSalesOutputController mssOutput = loader.getController();

					mssOutput.initAttributes((ServicesSalesOutput) o);
					
					// INITIALIZE COMBOBOXES:
					mssOutput.initCbServices();
				}

				stage.initStyle(StageStyle.UNDECORATED);
				stage.initStyle(StageStyle.TRANSPARENT);

				s.setFill(Color.TRANSPARENT);

				stage.setScene(s);
				stage.show();
			} catch (IOException ioe) {
				 ioe.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada. Existe un problema con el archivo fxml.");
			} catch (Exception ex) {
				ex.printStackTrace();

				AlertMessage.showErrorAndWait("La vista  no pudo ser cargada.");
			}
		}
	}

	public static void newButtonHoverIn(Button button) {
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: white; -fx-background-color: lime;");
	}

	public static void newButtonHoverOut(Button button) {
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: white; -fx-background-color: forestgreen;");
	}

	public static void modifyButtonHoverIn(Button button) {
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: white; -fx-background-color: fuchsia;");
	}

	public static void modifyButtonHoverOut(Button button) {
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: white; -fx-background-color: blueviolet;");
	}

	public static void whiteAndBlueButtonHoverIn(Button button) {
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: white; -fx-background-color: cyan;");

		button.setTextFill(Color.WHITE);
	}

	public static void whiteAndBlueButtonHoverOut(Button button) {
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: navy; -fx-background-color: white;");

		button.setTextFill(Color.NAVY);
	}
}
