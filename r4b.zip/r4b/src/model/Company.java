package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataInsertion;
import r4b_ddbb_management.DataSelector;
import r4b_ddbb_management.DataUpdate;

public class Company {
	// ATTRIBUTES companies_header:
	private int id;
	private String cif;
	private String name;
	// ATTRIBUTES companies_details:
	private boolean naturalPerson;
	private String address;
	private String city;
	private String province;
	private String postCode;
	private String country;

	// AFFECTED ROWS NUMBER:
	private int rows = 0;

	// CONSTRUCTOR BY DEFAULT:
	public Company() {

	}

	// CONSTRUCTOR FOR TABLE CompaniesController:
	public Company(int id, String cif, String name) {
		this.id = id;
		this.cif = cif;
		this.name = name;
	}

	// CONSTRUCTOR TO INSERT COMPANY HEADER:
	public Company(String cif, String name) {
		this.cif = cif;
		this.name = name;
	}

	// CONSTRUCTOR TO INSERT COMPANY DETAILS:
	public Company(int id, boolean naturalPerson, String address, String city, String province, String postCode,
			String country) {
		this.id = id;
		this.naturalPerson = naturalPerson;
		this.address = address;
		this.city = city;
		this.province = province;
		this.postCode = postCode;
		this.country = country;
	}

	// CONSTRUCTOR TO GET COMPANYID:
	public Company(String name) {
		this.name = name;
	}

	// GETTERS AND SETTERS:

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isNaturalPerson() {
		return naturalPerson;
	}

	public void setNaturalPerson(boolean naturalPerson) {
		this.naturalPerson = naturalPerson;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	// ---------------------------------------------------------------------------------------------------------

	// SELECT companies_header:
	public ObservableList<Company> getCompanies() {
		ObservableList<Company> obs = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("select id, cif, name from companies_header");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt("id");
				cif = rs.getString("cif");
				name = rs.getString("name");

				// MAKE OBJECT Company
				Company c = new Company(id, cif, name);

				obs.add(c);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los datos en la tabla.");
		}

		// RETURN ObservableList:
		return obs;
	}

	// SELECT id OF COMPANY:
	public String getStringCompanyId() {
		String sId = "";

		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQueryWithRestrictionString("call get_company_id_with_cif(?)", getCif());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt("id");
			}

			sId = getId() + "";

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� al mostrar id.");
		}

		// RETURN ObservableList:
		return sId;
	}

	// ---------------------------------------------------------------------------------------------------------

	// GET NAME OF COMPANY:
	public ObservableList<String> getCompanyName() {
		ObservableList<String> ols = FXCollections.observableArrayList();

		try {
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", "root", "Atleti1989");

			connection.getC();

			// STRING QUERY:
			String sQuery = "SELECT `name` FROM companies_header ORDER BY id";

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// MAKE OBJECT ResultSet:
			ResultSet rs = ps.executeQuery();

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				name = rs.getString(1);

				ols.add(name);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		// RETURN ObservableList:
		return ols;
	}
	// ----------------------------------------------------------------------------------------
	
	// GET  BUSINESS PARTNER DETAILS FOR FORM TO MODIFY:
	public void getCompanyDetails() {
		try {
			// INSTANCE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQueryWithRestrictionInt("call get_company_details_with_id(?);", getId());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				setNaturalPerson(rs.getBoolean(1));
				setAddress(rs.getString(2));
				setCity(rs.getString(3));
				setProvince(rs.getString(4));
				setPostCode(rs.getString(5));
				setCountry(rs.getString(6));
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();
			
			AlertMessage.showErrorAndWait("Error al obtener los detalles de la compa��a.");
		}
	}

	// ----------------------------------------------------------------------------------------

	// GET COMPANY ID:
	public int getCompanyIdWithName() {
		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQueryWithRestrictionString("call get_company_id_with_name(?)", getName());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� al obtener el id de la compa��a.");
		}

		// RETURN ObservableList:
		return id;
	}

	// ----------------------------------------------------------------------------------------

	// ---------------------------------------------------------------------------------------------------------

	// INSERT COMPANY HEADER:
	public boolean insertCompanyHeader() {
		try {
			rows = DataInsertion.insertCompanyHeaderData(getCif(), getName());

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� al insertar la cabecera de la compa��a.");
		}

		return false;
	}

	// ---------------------------------------------------------------------------------------------------------

	// ---------------------------------------------------------------------------------------------------------

	// INSERT COMPANY DETAILS:
	public boolean insertCompanyDetails() {
		try {
			rows = DataInsertion.insertCompanyDetailsData(getId(), isNaturalPerson(), getAddress(), getCity(),
					getProvince(), getPostCode(), getCountry());

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� al insertar los detalles de la compa��a.");
		}

		return false;
	}

	// ---------------------------------------------------------------------------------------------------------
	
	// UPDATE COMPANY HEADER:
	public boolean updateCompanyHeader() {
		try {			
			rows = DataUpdate.updateHeaderData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar la cabecera de la compa��a.");
		}

		return false;
	}

	// ---------------------------------------------------------------------------------------------------------
	
	// UPDATE COMPANY HEADER:
	public boolean updateCompanyDetails() {
		try {			
			rows = DataUpdate.updateDetailsOrLinesData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar la cabecera de la compa��a.");
		}

		return false;
	}

	// ---------------------------------------------------------------------------------------------------------
}
