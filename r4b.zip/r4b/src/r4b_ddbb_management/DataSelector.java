package r4b_ddbb_management;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class DataSelector {
	// SELECT QUERY:
	public static ResultSet selectQuery(String query) {
		ResultSet rs = null;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			connection.getC();

			// STRING QUERY:
			String sQuery = query;

			// INSTANCE OBJECT PreparedStatement:
			PreparedStatement ps;

			ps = connection.getC().prepareStatement(sQuery);

			// INSTANCE OBJECT ResultSet:
			rs = ps.executeQuery();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		return rs;
	}

	// ------------------------------------------------------------------------------------------------------------------------------

	// QUERY SELECT INT WITH STRING:
	public static ResultSet selectQueryWithRestrictionString(String query, String restriction) {
		// MAKE OBJECT ResultSet:
		ResultSet rs = null;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			connection.getC();

			// STRING QUERY:
			String sQuery = query;

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setString(1, restriction);

			// EXECUTE ResultSet:
			rs = ps.executeQuery();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		return rs;
	}

	// ------------------------------------------------------------------------------------------------------------------------------

	// QUERY SELECT A INT WITH ANOTHER INT:
	public static ResultSet selectQueryWithRestrictionInt(String query, int restriction) {
		// MAKE OBJECT ResultSet:
		ResultSet rs = null;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			connection.getC();

			// STRING QUERY:
			String sQuery = query;

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setInt(1, restriction);

			// EXECUTE QUERY:
			rs = ps.executeQuery();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		return rs;
	}

	// ------------------------------------------------------------------------------------------------------------------------------

	// QUERY SELECT INT WITH INT AND STRING:
	public static ResultSet selectQueryWithRestrictionIntAndString(String query, int restrictionInt,
			String restrictionString) {
		// MAKE OBJECT ResultSet:
		ResultSet rs = null;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			connection.getC();

			// STRING QUERY:
			String sQuery = query;

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setInt(1, restrictionInt);
			ps.setString(2, restrictionString);

			// EXECUTE ResultSet:
			rs = ps.executeQuery();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		return rs;
	}

	// ------------------------------------------------------------------------------------------------------------------------------
}
