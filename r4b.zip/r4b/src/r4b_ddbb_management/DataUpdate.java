package r4b_ddbb_management;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import model.BusinessPartner;
import model.Company;
import model.Measure;
import model.Service;
import model.ServiceType;
import model.ServicesSalesOrder;
import model.ServicesSalesOutput;

public class DataUpdate {
	/*
	 * ESTA CLASE NO SE USA AL FINAL PORQUE PREFIERO HACER LA ACTUALIZACION
	 * DEPENDIENDO DEL OBJETO DEL MODELO QUE SE INTRODUZCA COMO ARGUMENTO. LA DEJO
	 * PARA TENERLA COMO REFERENCIA PARA EL USO DE VARARGS DE OBJETOS Y SU USO PARA
	 * ASIGNAR VALORES A ARGUMENTOS DE LA QUERY.
	 * 
	 * public static int updateData(Object... o) { // AFFECTED ROWS: int rows = 0;
	 * 
	 * try { // OPEN CONNECTION: ConnectionDb connection = new
	 * ConnectionDb("localhost", "root", "Atleti1989");
	 * 
	 * // STRING QUERY String sQuery =
	 * "call update_business_partner_header(?, ?, ?, ?, ?)";
	 * 
	 * // MAKE OBJECT PreparedStatement: PreparedStatement ps =
	 * connection.getC().prepareStatement(sQuery);
	 * 
	 * // SET VALUES: ps.setInt(1, (Integer) o[0]); ps.setString(2, (String) o[1]);
	 * ps.setString(3, (String) o[2]); ps.setBoolean(4, (Boolean) o[3]);
	 * ps.setBoolean(5, (Boolean) o[4]);
	 * 
	 * // RETURN NUMBER ROWS AFFECTED: rows = ps.executeUpdate(); } catch
	 * (SQLException sqle) { // sqle.printStackTrace();
	 * 
	 * JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode()
	 * + "\n." + sqle.getMessage(), "Error", 0); } catch (Exception e) {
	 * e.printStackTrace();
	 * 
	 * JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(),
	 * "Error", 0); }
	 * 
	 * // CLOSE CONECTION: ConnectionDb.closeConnection();
	 * 
	 * // RETURN AFFECTED ROWS: return rows; }
	 */

	public static int updateHeaderData(Object o) {
		// GET CLASS NAME FROM OBJECT:
		String objectClassName = o.getClass().getName();
		// AFFECTED ROWS:
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = "";

			// SET VALUE TO STRING QUERY DEPENDING ON OBJECT:
			if (objectClassName.equals(BusinessPartner.class.getName())) {
				sQuery = "call update_business_partner_header(?, ?, ?, ?, ?)";
			} else if (objectClassName.equals(Company.class.getName())) {
				sQuery = "call update_company_header(?, ?, ?)";
			} else if (objectClassName.equals(Measure.class.getName())) {
				sQuery = "call update_measure(?, ?)";
			} else if (objectClassName.equals(ServiceType.class.getName())) {
				sQuery = "call update_service_type(?, ?, ?)";
			} else if (objectClassName.equals(Service.class.getName())) {
				sQuery = "call update_service(?, ?, ?, ?, ?, ?)";
			} else if (objectClassName.equals(ServicesSalesOrder.class.getName())) {
				sQuery = "call update_services_sales_order_header(?, ?, ?, ?)";
			} else if (objectClassName.equals(ServicesSalesOutput.class.getName())) {
				sQuery = "call update_services_sales_output_header(?, ?, ?)";
			}

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES DEPENDING ON OBJECT:
			if (objectClassName.equals(BusinessPartner.class.getName())) {
				ps.setInt(1, ((BusinessPartner) o).getId());
				ps.setString(2, ((BusinessPartner) o).getCif());
				ps.setString(3, ((BusinessPartner) o).getName());
				ps.setBoolean(4, ((BusinessPartner) o).isCustomer());
				ps.setBoolean(5, ((BusinessPartner) o).isSupplier());
			} else if (objectClassName.equals(Company.class.getName())) {
				ps.setInt(1, ((Company) o).getId());
				ps.setString(2, ((Company) o).getCif());
				ps.setString(3, ((Company) o).getName());
			} else if (objectClassName.equals(Measure.class.getName())) {
				ps.setInt(1, ((Measure) o).getId());
				ps.setString(2, ((Measure) o).getName());
			} else if (objectClassName.equals(ServiceType.class.getName())) {
				ps.setInt(1, ((ServiceType) o).getId());
				ps.setString(2, ((ServiceType) o).getServiceType());
				ps.setString(3, ((ServiceType) o).getDescription());
			} else if (objectClassName.equals(Service.class.getName())) {
				ps.setInt(1, ((Service) o).getId());
				ps.setInt(2, ((Service) o).getServiceTypeId());
				ps.setInt(3, ((Service) o).getMeasureId());
				ps.setString(4, ((Service) o).getName());
				ps.setString(5, ((Service) o).getDescription());
				ps.setFloat(6, ((Service) o).getUPrice());
			} else if (objectClassName.equals(ServicesSalesOrder.class.getName())) {
				ps.setInt(1, ((ServicesSalesOrder) o).getOrderId());
				ps.setInt(2, ((ServicesSalesOrder) o).getCompanyId());
				ps.setInt(3, ((ServicesSalesOrder) o).getBusinessPartnerId());
				ps.setDate(4, (Date.valueOf(((ServicesSalesOrder) o).getOrderDate())));
			} else if (objectClassName.equals(ServicesSalesOutput.class.getName())) {
				ps.setInt(1, ((ServicesSalesOutput) o).getOutputId());
				ps.setInt(2, ((ServicesSalesOutput) o).getOrderId());
				ps.setDate(3, (Date.valueOf(((ServicesSalesOutput) o).getOutputDate())));
			}

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}

	public static int updateDetailsOrLinesData(Object o) {
		// GET CLASS NAME FROM OBJECT:
		String objectClassName = o.getClass().getName();
		// AFFECTED ROWS:
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = "";

			// SET VALUE TO STRING QUERY DEPENDING ON OBJECT:
			if (objectClassName.equals(BusinessPartner.class.getName())) {
				sQuery = "call update_business_partner_details(?, ?, ?, ?, ?, ?, ?);";
			} else if (objectClassName.equals(Company.class.getName())) {
				sQuery = "call update_company_details(?, ?, ?, ?, ?, ?, ?);";
			} else if (objectClassName.equals(ServicesSalesOrder.class.getName())) {
				sQuery = "call update_services_sales_order_details(?, ?, ?, ?, ?)";
			} else if (objectClassName.equals(ServicesSalesOutput.class.getName())) {
				sQuery = "call update_services_sales_output_details(?, ?, ?, ?)";
			}

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES DEPENDING ON OBJECT:
			if (o.getClass().getName().equals(BusinessPartner.class.getName())) {
				ps.setInt(1, ((BusinessPartner) o).getId());
				ps.setBoolean(2, ((BusinessPartner) o).isNaturalPerson());
				ps.setString(3, ((BusinessPartner) o).getAddress());
				ps.setString(4, ((BusinessPartner) o).getCity());
				ps.setString(5, ((BusinessPartner) o).getProvince());
				ps.setString(6, ((BusinessPartner) o).getPostCode());
				ps.setString(7, ((BusinessPartner) o).getCountry());
			} else if (o.getClass().getName().equals(Company.class.getName())) {
				ps.setInt(1, ((Company) o).getId());
				ps.setBoolean(2, ((Company) o).isNaturalPerson());
				ps.setString(3, ((Company) o).getAddress());
				ps.setString(4, ((Company) o).getCity());
				ps.setString(5, ((Company) o).getProvince());
				ps.setString(6, ((Company) o).getPostCode());
				ps.setString(7, ((Company) o).getCountry());
			} else if (objectClassName.equals(ServicesSalesOrder.class.getName())) {
				ps.setInt(1, ((ServicesSalesOrder) o).getOrderId());
				ps.setInt(2, ((ServicesSalesOrder) o).getLineId());
				ps.setInt(3, ((ServicesSalesOrder) o).getServiceId());
				ps.setInt(4, ((ServicesSalesOrder) o).getProfitabilityId());
				ps.setInt(5, ((ServicesSalesOrder) o).getQuantity());
			} else if (objectClassName.equals(ServicesSalesOutput.class.getName())) {
				ps.setInt(1, ((ServicesSalesOutput) o).getOutputId());
				ps.setInt(2, ((ServicesSalesOutput) o).getOutputLineId());
				ps.setInt(3, ((ServicesSalesOutput) o).getOrderLineId());
				ps.setInt(4, ((ServicesSalesOutput) o).getQuantity());
			}

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}
}
