USE third_factor_lts;

DELIMITER $$

CREATE TRIGGER after_insert_service_type
    AFTER INSERT ON service_type
    FOR EACH ROW 

BEGIN
INSERT INTO modified_services_type
SET 
	modified_services_type.`service_type_id` = new.id,
    modified_services_type.`field_name` = null,
    modified_services_type.`user` = CURRENT_USER(),
    modified_services_type.`old_value` = null,
    modified_services_type.`new_value` = null,
    modified_services_type.`update_date` = CURRENT_DATE(),
    modified_services_type.`transaction` = 'INSERT';
END$$
	
DELIMITER ;

DELIMITER $$

CREATE TRIGGER after_update_service_type
    AFTER UPDATE ON service_type
    FOR EACH ROW
    
    BEGIN

	IF old.`service_type` <> new.`service_type` THEN
		INSERT INTO modified_services_type (`service_type_id`, `field_name`, `user`, `old_value`, `new_value`, `update_date`, `transaction`)
		VALUES (new.`id`, 'service_type', CURRENT_USER(), old.`service_type`, new.`service_type`, CURRENT_DATE(), 'UPDATE');
	END IF;
    
	IF old.`description` <> new.`description` THEN
		INSERT INTO modified_services_type (`service_type_id`, `field_name`, `user`, `old_value`, `new_value`, `update_date`, `transaction`)
		VALUES (new.`id`, 'description', CURRENT_USER(), old.`description`, new.`description`, CURRENT_DATE(), 'UPDATE');
	END IF;
    
    END$$

DELIMITER ;