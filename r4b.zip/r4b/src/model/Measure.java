package model;

import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataInsertion;
import r4b_ddbb_management.DataSelector;
import r4b_ddbb_management.DataUpdate;

public class Measure {
	private int id;
	private String name;

	// AFFECTED ROWS NUMBER:
	private int rows = 0;

	// CONSTRUCTOR BY DEFAULT:
	public Measure() {

	}

	// CONSTRUCTOR TABLE measures:
	public Measure(int id, String name) {
		this.id = id;
		this.name = name;
	}

	// CONSTRUCTOR TO INSERT MEASURE:
	public Measure(String name) {
		this.name = name;
	}

	// GETTERS AND SETTERS:

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	// --------------------------------------------------------

	// SELECT measures:
	public ObservableList<Measure> getMeasures() {
		ObservableList<Measure> obs = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQuery("select id, name from measures order by id");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
				name = rs.getString(2);

				// MAKE OBJECT Company
				Measure m = new Measure(id, name);

				obs.add(m);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los datos en la tabla.");
		}

		// RETURN ObservableList:
		return obs;
	}

	// ------------------------------------------------------------------------------------------------------

	// GET NAME OF MEASURE:
	public ObservableList<String> getMeasuresName() {
		ObservableList<String> obs = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet AND :
			ResultSet rs = DataSelector.selectQuery("SELECT name FROM measures ORDER BY id");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				name = rs.getString(1);

				obs.add(name);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar las medidas.");
		}

		// RETURN ObservableList:
		return obs;
	}
	// ----------------------------------------------------------------------------------------

	// GET ID OF MEASURE:
	public int getMeasureIdWithName() {
		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQueryWithRestrictionString("call get_measure_id_with_name(?)", getName());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al obtener el id de la medida.");
		}

		// RETURN ObservableList:
		return id;
	}
	// ----------------------------------------------------------------------------------------

	// INSERT MEASURE:
	public boolean insertMeasure() {
		try {
			rows = DataInsertion.insertMeasureData(getName());

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al insertar la medida.");
		}

		return false;
	}

	// ----------------------------------------------------------------------------------------
	
	// UPDATE MEASURE:
	public boolean updateMeasure() {
		try {			
			rows = DataUpdate.updateHeaderData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar la medida.");
		}

		return false;
	}
}
