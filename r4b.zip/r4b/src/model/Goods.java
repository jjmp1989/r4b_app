package model;

import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataSelector;

public class Goods {
	// ATTRIBUTES FOR TABLE goods:
	private int id;
	private String name;
	private String description;
	private int quantity;
	private int measureId;
	private Float waccValue;
	private Float uWaccValue;

	// ATTRIBUTES FOR VIEW v_goods:
	private String measureName;

	public Goods() {

	}

	// CONSTRUCTOR FOR TABLE goods:
	public Goods(int id, String name, String description, int quantity, int measureId, Float waccValue,
			Float uWaccValue) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.quantity = quantity;
		this.measureId = measureId;
		this.waccValue = waccValue;
		this.uWaccValue = uWaccValue;
	}

	// CONSTRUCTOR FOR VIEW v_goods:
	public Goods(int id, String name, String description, int quantity, String measureName, Float waccValue,
			Float uWaccValue) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.quantity = quantity;
		this.measureName = measureName;
		this.waccValue = waccValue;
		this.uWaccValue = uWaccValue;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getMeasureId() {
		return measureId;
	}

	public void setMeasureId(int measureId) {
		this.measureId = measureId;
	}

	public Float getWaccValue() {
		return waccValue;
	}

	public void setWaccValue(Float waccValue) {
		this.waccValue = waccValue;
	}

	public Float getUWaccValue() {
		return uWaccValue;
	}

	public void setUWaccValue(Float uWaccValue) {
		this.uWaccValue = uWaccValue;
	}
	
	public String getMeasureName() {
		return measureName;
	}

	public void setMeasureName(String measureName) {
		this.measureName = measureName;
	}

	// SHOW companies IN TABLE OF VIEW Companies.fxml:
	public ObservableList<Goods> getGoods() {
		ObservableList<Goods> obs = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("select * from v_goods");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
				name = rs.getString(2);
				description = rs.getString(3);
				quantity = rs.getInt(4);
				measureName = rs.getString(5);
				waccValue = rs.getFloat(6);
				uWaccValue = rs.getFloat(7);

				// MAKE OBJECT goods
				Goods g = new Goods(id, name, description, quantity, measureName, waccValue, uWaccValue);

				obs.add(g);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();
			
			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los datos en la tabla.");
		}
		
		// RETURN ObservableList:
		return obs;
	}
}
