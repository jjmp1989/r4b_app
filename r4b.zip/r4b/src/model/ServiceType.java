package model;

import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataInsertion;
import r4b_ddbb_management.DataSelector;
import r4b_ddbb_management.DataUpdate;

public class ServiceType {
	// ATTRIBUTES FOR TABLE services_types:
	private int id;
	private String serviceType;
	private String description;
	// AFFECTED ROWS NUMBER:
	private int rows = 0;

	// CONSTRUCTOR BY DEFAULT:
	public ServiceType() {

	}

	// CONSTRUCTOR FOR TABLE services_types:
	public ServiceType(int id, String serviceType, String description) {
		this.id = id;
		this.serviceType = serviceType;
		this.description = description;
	}

	// CONSTRUCTOR TO INSERT SERVICES TYPES:
	public ServiceType(String serviceType, String description) {
		this.serviceType = serviceType;
		this.description = description;
	}

	// CONSTRUCTOR TO GET ID OF SERVICES TYPES:
	public ServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	// GETTERS AND SETTERS:

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	// --------------------------------------------------------------------------------

	// SHOW services_types IN TABLE OF VIEW ServicesTypes.fxml:
	public ObservableList<ServiceType> getServicesTypes() {
		ObservableList<ServiceType> olSt = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("select id, service_type, description from service_type");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt("id");
				serviceType = rs.getString("service_type");
				description = rs.getString("description");

				// MAKE OBJECT ServiceType
				ServiceType st = new ServiceType(id, serviceType, description);

				olSt.add(st);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los datos en la tabla.");
		}

		// RETURN ObservableList:
		return olSt;
	}

	// GET NAME OF SERVICE TYPE:
	public ObservableList<String> getServiceTypeName() {
		ObservableList<String> olServiceType = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("SELECT service_type FROM service_type ORDER BY id");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				serviceType = rs.getString(1);

				olServiceType.add(serviceType);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar el Tipo de Servicio.");
		}

		// RETURN ObservableList:
		return olServiceType;
	}
	// ----------------------------------------------------------------------------------------

	// GET ID OF SERVICE TYPE:
	public int getServiceTypeIdWithName() {
		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQueryWithRestrictionString("call get_service_type_id_with_name(?)",
					getServiceType());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al obtener el id del Tipo de Servicio.");
		}

		// RETURN ObservableList:
		return id;
	}
	// ----------------------------------------------------------------------------------------

	// METHOD TO INSERT SERVICE TYPE:
	public boolean insertServiceType() {
		try {
			rows = DataInsertion.insertServiceTypeData(getServiceType(), getDescription());

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al insertar el Tipo de Servicio.");
		}

		return false;
	}
	
	// ----------------------------------------------------------------------------------------
	// UPDATE SERVICE TYPE:
	public boolean updateServiceType() {
		try {			
			rows = DataUpdate.updateHeaderData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar la cabecera de la compa��a.");
		}

		return false;
	}
}
