package model;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataSelector;

public class GoodsReception {
	// ATTRIBUTES FOR TABLE goods_reception_header:
	private int receptionId;
	private int orderId;
	private Date receptionDate;

	// ATTRIBUTES FOR VIEW v_goods_reception_header:
	private String companyName;
	private String businessPartnerName;

	// ATTRIBUTES FOR TABLE goods_reception_lines:

	// ATTRIBUTES FOR VIEW v_goods_reception_lines:

	// CONTRUCTOR BY DEFAULT:
	public GoodsReception() {

	}

	// CONTRUCTOR FOR TABLE goods_reception_header::
	public GoodsReception(int receptionId, int orderId, Date receptionDate) {
		super();
		this.receptionId = receptionId;
		this.orderId = orderId;
		this.receptionDate = receptionDate;
	}

	// CONSTRUCTOR FOR VIEW v_goods_reception_header:
	public GoodsReception(int receptionId, int orderId, Date receptionDate, String companyName,
			String businessPartnerName) {
		super();
		this.receptionId = receptionId;
		this.orderId = orderId;
		this.receptionDate = receptionDate;
		this.companyName = companyName;
		this.businessPartnerName = businessPartnerName;
	}

	// GETTERS AND SETTERS:	---------------------------------------

	public int getReceptionId() {
		return receptionId;
	}

	public void setReceptionId(int receptionId) {
		this.receptionId = receptionId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Date getReceptionDate() {
		return receptionDate;
	}

	public void setReceptionDate(Date receptionDate) {
		this.receptionDate = receptionDate;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBusinessPartnerName() {
		return businessPartnerName;
	}

	public void setBusinessPartnerName(String businessPartnerName) {
		this.businessPartnerName = businessPartnerName;
	}
	
	// -----------------------------------------------------------------------------------

	// SHOW goods reception IN TABLE OF VIEW GoodsReception.fxml:
	public ObservableList<GoodsReception> getGoodsReceptions() {
		ObservableList<GoodsReception> obs = FXCollections.observableArrayList();

		try {
			// INSTANCE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("select * from v_goods_reception_header");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				receptionId = rs.getInt(1);
				orderId = rs.getInt(2);
				companyName = rs.getString(3);
				businessPartnerName = rs.getString(4);
				receptionDate = rs.getDate(5);

				// INSTANCE OBJECT GoodsReception:
				GoodsReception gr = new GoodsReception(receptionId, orderId, receptionDate, companyName,
						businessPartnerName);

				obs.add(gr);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();
			
			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los datos en la tabla.");
		}

		// RETURN ObservableList:
		return obs;
	}
}
