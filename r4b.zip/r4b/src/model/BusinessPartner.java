package model;

import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataInsertion;
import r4b_ddbb_management.DataSelector;
import r4b_ddbb_management.DataUpdate;

public class BusinessPartner {
	// ATRIBUTES business_partner_header:
	private int id;
	private String cif;
	private String name;
	private Boolean customer;
	private Boolean supplier;
	// ATRIBUTES business_partner_details:
	private boolean naturalPerson;
	private String address;
	private String city;
	private String province;
	private String postCode;
	private String country;

	// AFFECTED ROWS NUMBER:
	private int rows = 0;

	// CONSTRUCTOR BY DEFAULT:
	public BusinessPartner() {

	}

	// CONSTRUCTOR FOR TABLE business_partner_header:
	public BusinessPartner(int id, String cif, String name, Boolean customer, Boolean supplier) {
		super();
		this.id = id;
		this.cif = cif;
		this.name = name;
		this.customer = customer;
		this.supplier = supplier;
	}

	// CONSTRUCTOR TO INSERT business_partner_header:
	public BusinessPartner(String cif, String name, Boolean customer, Boolean supplier) {
		this.cif = cif;
		this.name = name;
		this.customer = customer;
		this.supplier = supplier;
	}

	// CONSTRUCTOR FOR TABLE business_partner_details:
	public BusinessPartner(int id, boolean naturalPerson, String address, String city, String province, String postCode,
			String country) {
		this.id = id;
		this.naturalPerson = naturalPerson;
		this.address = address;
		this.city = city;
		this.province = province;
		this.postCode = postCode;
		this.country = country;
	}

	// CONSTRUCTOR TO GET BUSINESS PARTNER ID:
	public BusinessPartner(String name) {
		this.name = name;
	}

	// GETTERS AND SETTERS:

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCif() {
		return cif;
	}

	public void setCif(String cif) {
		this.cif = cif;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean isCustomer() {
		return customer;
	}

	public void setCustomer(Boolean customer) {
		this.customer = customer;
	}

	public Boolean isSupplier() {
		return supplier;
	}

	public void setSupplier(Boolean supplier) {
		this.supplier = supplier;
	}

	public boolean isNaturalPerson() {
		return naturalPerson;
	}

	public void setNaturalPerson(boolean naturalPerson) {
		this.naturalPerson = naturalPerson;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	// ------------------------------------------------------------------------------------------------

	// SELECT business_partner_header:
	public ObservableList<BusinessPartner> getBusinessPartner() {
		ObservableList<BusinessPartner> obs = FXCollections.observableArrayList();

		try {
			// INSTANCE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("select *  from business_partner_header");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
				cif = rs.getString(2);
				name = rs.getString(3);
				customer = rs.getBoolean(4);
				supplier = rs.getBoolean(5);

				// INSTANCE OBJECT BusinessPartner
				BusinessPartner bp = new BusinessPartner(id, cif, name, customer, supplier);

				obs.add(bp);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los datos en la tabla.");
		}

		// RETURN ObservableList:
		return obs;
	}

	// -----------------------------------------------------------------------------------------------------

	// SELECT id OF BUSINESS PARTNER:
	public String getStringBusinessPartnerId() {
		String sId = "";

		try {
			/*
			 * // OPEN CONNECTION ConnectionDb connection = new ConnectionDb("localhost",
			 * "root", "Atleti1989");
			 * 
			 * connection.getC();
			 * 
			 * // STRING QUERY: String sQuery = "call get_business_partner_id_with_cif(?)";
			 * 
			 * // MAKE OBJECT PreparedStatement: PreparedStatement ps =
			 * connection.getC().prepareStatement(sQuery);
			 * 
			 * // SET VALUES: ps.setString(1, getCif());
			 * 
			 * // MAKE OBJECT ResultSet: ResultSet rs = ps.executeQuery();
			 */
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQueryWithRestrictionString("call get_business_partner_id_with_cif(?)", getCif());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt("id");
			}

			sId = getId() + "";

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� al mostrar id.");
		}

		// RETURN ObservableList:
		return sId;
	}

	// ---------------------------------------------------------------------------------------------------------

	// GET NAME OF BUSINESS PARTNER:
	public ObservableList<String> getCustomerName() {
		ObservableList<String> ols = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQuery("SELECT `name` FROM business_partner_header WHERE is_customer = TRUE ORDER BY id");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				name = rs.getString(1);

				ols.add(name);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los clientes.");
		}

		// RETURN ObservableList:
		return ols;
	}
	
	// ----------------------------------------------------------------------------------------
	
	// GET  BUSINESS PARTNER DETAILS FOR FORM TO MODIFY:
	public void getBusinessPartnerDetails() {
		try {
			// INSTANCE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQueryWithRestrictionInt("call get_business_partner_details_with_id(?);", getId());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				setNaturalPerson(rs.getBoolean(1));
				setAddress(rs.getString(2));
				setCity(rs.getString(3));
				setProvince(rs.getString(4));
				setPostCode(rs.getString(5));
				setCountry(rs.getString(6));
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();
			
			AlertMessage.showErrorAndWait("Error al obtener los detalles del socio comercial.");
		}
	}

	// ----------------------------------------------------------------------------------------

	// GET BUSINESS PARTNER ID:
	public int getBusinessPartnerIdWithName() {
		try {
			/*
			 * // OPEN CONNECTION ConnectionDb connection = new ConnectionDb("localhost",
			 * "root", "Atleti1989");
			 * 
			 * connection.getC();
			 * 
			 * // STRING QUERY: String sQuery = "call get_business_partner_id_with_name(?)";
			 * 
			 * // MAKE OBJECT PreparedStatement: PreparedStatement ps =
			 * connection.getC().prepareStatement(sQuery);
			 * 
			 * // SET VALUES: ps.setString(1, getName());
			 * 
			 * // MAKE OBJECT ResultSet: ResultSet rs = ps.executeQuery();
			 */

			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQueryWithRestrictionString("call get_business_partner_id_with_name(?)",
					getName());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri�un error al obtener el id del socio comercial.");
		}

		// RETURN ObservableList:
		return id;
	}

	// ----------------------------------------------------------------------------------------

	// INSERT BUSINESS PARTNER HEADER:
	public boolean insertBusinessPartnerHeader() {
		try {			
			rows = DataInsertion.insertBusinessPartnerHeaderData(getCif(), getName(), isCustomer(), isSupplier());

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al insertar la cabecera el socio comercial.");
		}

		return false;
	}

	// ---------------------------------------------------------------------------------------------------------

	// INSERT BUSINESS PARTNER DETAILS:
	public boolean insertBusinessPartnerDetails() {
		try {
			rows = DataInsertion.insertBusinessPartnerDetailsData(getId(), isNaturalPerson(), getAddress(), getCity(), getProvince(), getPostCode(), getCountry());
			
			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al insertar el socio comercial.");
		}

		return false;
	}

	// ------------------------------------------------------------------------------------------------------------------------
	
	// UPDATE BUSINESS PARTNER HEADER:
	public boolean updateBusinessPartnerHeader() {
		try {			
			rows = DataUpdate.updateHeaderData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar la cabecera del socio comercial.");
		}

		return false;
	}

	// ---------------------------------------------------------------------------------------------------------
	
	// UPDATE BUSINESS PARTNER HEADER:
	public boolean updateBusinessPartnerDetails() {
		try {			
			rows = DataUpdate.updateDetailsOrLinesData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar los detalles del socio comercial.");
		}

		return false;
	}

	// ---------------------------------------------------------------------------------------------------------
}
