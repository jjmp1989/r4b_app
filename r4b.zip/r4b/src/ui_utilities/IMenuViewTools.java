package ui_utilities;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public interface IMenuViewTools {
	public static void moduleButtonChangeModule(Stage stage, FXMLLoader loader) {
		try {
			Parent parent = loader.load();
			Scene scene = new Scene(parent);
			
			scene.setFill(Color.TRANSPARENT);
			
			stage.setScene(scene);
			stage.show();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void menuViewButtonHoverIn(Button button) {
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: cyan; -fx-background-color: white;");
		
		button.setTextFill(Color.CYAN);
	}
	
	public static void menuViewButtonHoverOut(Button button) {
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: blue; -fx-background-color: white;");
		
		button.setTextFill(Color.BLUE);
	}
	
	public static void menuViewButtonMousePressed(Button button) {
		// TODO Auto-generated method stub
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: navy; -fx-background-color: white;");
		
		button.setTextFill(Color.NAVY);
	}

	public static void menuViewButtonMouseReleased(Button button) {
		// TODO Auto-generated method stub
		button.setStyle(
				"-fx-font-weight: Bold; -fx-background-radius: 1em; -fx-border-radius: 1em; -fx-border-color: blue; -fx-background-color: white;");
		
		button.setTextFill(Color.BLUE);
	}
}
