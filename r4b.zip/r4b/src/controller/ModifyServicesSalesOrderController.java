package controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;

import alert_messages.AlertMessage;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;

import javafx.scene.control.Label;
import javafx.scene.control.ComboBox;

import javafx.scene.input.MouseEvent;

import javafx.scene.layout.BorderPane;

import javafx.scene.input.KeyEvent;

import javafx.scene.control.DatePicker;

import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import model.BusinessPartner;
import model.Company;
import model.Service;
import model.ServiceProfitability;
import model.ServicesSalesOrder;
import styles.InitializableStyle;
import ui_utilities.IFormValidation;
import ui_utilities.IFormWindow;
import ui_utilities.ITitleBarTools;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableView.TableViewSelectionModel;

public class ModifyServicesSalesOrderController implements Initializable {
	@FXML
	private BorderPane bpAll;
	@FXML
	private GridPane gpTitleBar;
	@FXML
	private Label lTitle;
	@FXML
	private Button bClose;
	@FXML
	private Button bMinimise;
	@FXML
	private Button bChangeSize;
	@FXML
	private Button bSaveHeader;
	@FXML
	private Button bSaveLine;
	@FXML
	private Button bSaveLineClose;
	@FXML
	private BorderPane bpWorkView;
	@FXML
	private Label lCompany;
	@FXML
	private Label lCustomer;
	@FXML
	private Label lHeader;
	@FXML
	private Label lOrderNumber;
	@FXML
	private Label lLine;
	@FXML
	private Label lDate;
	@FXML
	private Label lService;
	@FXML
	private Label lQuantity;
	@FXML
	private Label lProfitability;
	@FXML
	private Label lOrderLineNumber;
	@FXML
	private TextField tfOrderNumber;
	@FXML
	private TextField tfOrderLineNumber;
	@FXML
	private TextField tfQuantity;
	@FXML
	private DatePicker dpDate;
	@FXML
	private ComboBox<String> cbCompany;
	@FXML
	private ComboBox<String> cbCustomer;
	@FXML
	private ComboBox<String> cbService;
	@FXML
	private ComboBox<String> cbProfitability;
	@FXML
	private TableView<ServicesSalesOrder> tRecord;
	@FXML
	private TableColumn<ServicesSalesOrder, Integer> cLineId;
	@FXML
	private TableColumn<ServicesSalesOrder, String> cServiceName;
	@FXML
	private TableColumn<ServicesSalesOrder, Float> cUInventoryPrice;
	@FXML
	private TableColumn<ServicesSalesOrder, Integer> cProfitability;
	@FXML
	private TableColumn<ServicesSalesOrder, Float> cUSalePrice;
	@FXML
	private TableColumn<ServicesSalesOrder, Integer> cQuantity;
	@FXML
	private TableColumn<ServicesSalesOrder, Float> cTotal;

	// FOR EVENT ABOUT MOVING WINDOW:
	private double coordinateList[];

	// FOR COMBOBOX:
	private ObservableList<String> olCompany;
	private ObservableList<String> olCustomer;
	private ObservableList<String> olServices;
	private ObservableList<String> olProfitability;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub

		// INITIAL STYLE:
		InitializableStyle.InitializeStyleFormWindowWithTable(lTitle, bpWorkView);

		// INITIALIZE COMBOBOXES:
		initCbCompany();

		initCbCustomer();

		initCbServices();

		initCbProfitability();
	}

	// INIT ATTRIBUTES:
	public void initAttributes(ServicesSalesOrder pSso) {
		ServicesSalesOrder sso = pSso;

		// INITIALIZE HEADER:
		tfOrderNumber.setText(sso.getOrderId() + "");
		cbCompany.setValue(sso.getCompanyName());
		cbCustomer.setValue(sso.getBusinessPartnerName());
		dpDate.setValue(sso.getOrderDate());

		// INITIALIZE LINES:
		loadDataInTable();
	}

	// SHOW services_sales_order_lines IN TABLE:
	public void loadDataInTable() {
		this.cLineId.setCellValueFactory(new PropertyValueFactory<ServicesSalesOrder, Integer>("lineId"));
		this.cServiceName.setCellValueFactory(new PropertyValueFactory<ServicesSalesOrder, String>("serviceName"));
		this.cUInventoryPrice
				.setCellValueFactory(new PropertyValueFactory<ServicesSalesOrder, Float>("uInventoryPrice"));
		this.cProfitability
				.setCellValueFactory(new PropertyValueFactory<ServicesSalesOrder, Integer>("profitabilityPercentage"));
		this.cUSalePrice.setCellValueFactory(new PropertyValueFactory<ServicesSalesOrder, Float>("uSalePrice"));
		this.cQuantity.setCellValueFactory(new PropertyValueFactory<ServicesSalesOrder, Integer>("quantity"));
		this.cTotal.setCellValueFactory(new PropertyValueFactory<ServicesSalesOrder, Float>("totalPrice"));

		// LOAD DATA IN TABLE:
		ServicesSalesOrder sso = new ServicesSalesOrder();
		ObservableList<ServicesSalesOrder> items;

		sso.setOrderId(Integer.parseInt(tfOrderNumber.getText()));

		items = sso.getServicesSalesOrderLines();

		this.tRecord.setItems(items);
	}

	// START COMBOBOXES:
	// COMPANIES:
	public void initCbCompany() {
		Company c = new Company();
		olCompany = c.getCompanyName();

		this.cbCompany.setVisibleRowCount(15);
		this.cbCompany.setItems(olCompany);
	}

	// CUSTOMERS:
	public void initCbCustomer() {
		BusinessPartner bp = new BusinessPartner();
		olCustomer = bp.getCustomerName();

		this.cbCustomer.setVisibleRowCount(15);
		this.cbCustomer.setItems(olCustomer);
	}

	// SERVICES:
	public void initCbServices() {
		Service s = new Service();
		olServices = s.getServiceName();

		this.cbService.setVisibleRowCount(15);
		this.cbService.setItems(olServices);
	}

	// PROFITABILITIES:
	public void initCbProfitability() {
		ServiceProfitability sp = new ServiceProfitability();
		olProfitability = sp.getProfitabilitiesPercentages();

		this.cbProfitability.setVisibleRowCount(15);
		this.cbProfitability.setItems(olProfitability);
	}

	// ---------------------------------------------------

	// ----------------------------------------------------------------------------------------------------
	// EVENTS FOR TITLEBAR:
	// Event Listener on GridPane[#gpTitleBar].onMousePressed
	@FXML
	public void gptbMousePressed(MouseEvent event) {
		// TODO Autogenerated

		Stage stage = (Stage) this.bClose.getScene().getWindow();

		coordinateList = ITitleBarTools.gridPaneTitleBarPressed(event, stage);
	}

	// Event Listener on GridPane[#gpTitleBar].onMouseDragged
	@FXML
	public void gptbMouseDragged(MouseEvent event) {
		// TODO Autogenerated

		Stage stage = (Stage) this.bClose.getScene().getWindow();

		ITitleBarTools.gridPaneTitleBarDragged(event, stage, gpTitleBar, coordinateList);
	}

	// Event Listener on GridPane[#gpTitleBar].onMouseReleased
	@FXML
	public void gptbMouseReleased(MouseEvent event) {
		// TODO Autogenerated

		Stage stage = (Stage) this.bClose.getScene().getWindow();

		ITitleBarTools.gridPaneTitleBarMouseReleased(event, stage, gpTitleBar);
	}

	// Event Listener on Button[#bClose].onAction
	@FXML
	public void closeWindow(ActionEvent event) {
		// TODO Autogenerated

		Stage stage = (Stage) this.bClose.getScene().getWindow();

		ITitleBarTools.closeButtonCloseWindow(stage, bClose);
	}

	// Event Listener on Button[#bClose].onMouseEntered
	@FXML
	public void bCloseHoverIn(MouseEvent event) {
		// TODO Autogenerated

		ITitleBarTools.closeButtonHoverIn(bClose);
	}

	// Event Listener on Button[#bClose].onMouseExited
	@FXML
	public void bCloseHoverOut(MouseEvent event) {
		// TODO Autogenerated

		ITitleBarTools.closeButtonHoverOut(bClose);
	}

	// Event Listener on Button[#bMinimise].onAction
	@FXML
	public void minimiseWindow(ActionEvent event) {
		// TODO Autogenerated

		Stage stage = (Stage) this.bClose.getScene().getWindow();

		ITitleBarTools.minimiseButtonMinimiseWindow(stage);
	}

	// Event Listener on Button[#bMinimise].onMouseEntered
	@FXML
	public void bMinimiseHoverIn(MouseEvent event) {
		// TODO Autogenerated

		ITitleBarTools.minimiseButtonHoverIn(bMinimise);
	}

	// Event Listener on Button[#bMinimise].onMouseExited
	@FXML
	public void bMinimiseHoverOut(MouseEvent event) {
		// TODO Autogenerated

		ITitleBarTools.minimiseButtonHoverOut(bMinimise);
	}

	// Event Listener on Button[#bChangeSize].onAction
	@FXML
	public void changeSize(ActionEvent event) {
		// TODO Autogenerated

		Stage s = (Stage) this.bChangeSize.getScene().getWindow();

		ITitleBarTools.changeSizeButtonChangeSize(s, bChangeSize);
	}

	// Event Listener on Button[#bChangeSize].onMouseEntered
	@FXML
	public void bChangeSizeHoverIn(MouseEvent event) {
		// TODO Autogenerated

		ITitleBarTools.changeSizeButtonHoverIn(bChangeSize);
	}

	// Event Listener on Button[#bChangeSize].onMouseExited
	@FXML
	public void bChangeSizeHoverOut(MouseEvent event) {
		// TODO Autogenerated

		ITitleBarTools.changeSizeButtonHoverOut(bChangeSize);
	}

	// END TITLEBAR
	// ------------------------------------------------------------------------------------------
	
	// Event Listener on Button[#bSaveHeader].onAction
	@FXML
	public void saveServicesSaleOrderHeader(ActionEvent event) {
		// TODO Autogenerated

		// VALIDATION:
		String errors = IFormValidation.validateModifyServicesSalesOrderHeader(cbCompany, cbCustomer, olCompany, olCustomer,
				dpDate);

		if (errors.isEmpty()) {
			// OBJECTS FOR COMBOBOXES:
			String sCompany = cbCompany.getEditor().getText();
			String sCustomer = cbCustomer.getEditor().getText();
			Company c = new Company(sCompany);
			BusinessPartner bp = new BusinessPartner(sCustomer);
			int companyId = c.getCompanyIdWithName();
			int customerId = bp.getBusinessPartnerIdWithName();

			// MAKE OBJECT Service:
			ServicesSalesOrder sso = new ServicesSalesOrder(Integer.parseInt(tfOrderNumber.getText()), companyId,
					customerId, dpDate.getValue());

			// UPDATE OBJECT:
			if (sso.updateServicesSalesOrderHeader()) {
				AlertMessage.showInformationCorrectUpdateAndWait(sso.getRows());
			} else {
				AlertMessage.showErrorAndWait("Ocurri� un error durante la modificaci�n del registro.");
			}
		} else {
			AlertMessage.showErrorAndWait(errors);
		}
	}

	// Event Listener on Button[#bSaveHeader].onMouseEntered
	@FXML
	public void bSaveHeaderMouseEntered(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gpModifyBottomButtonHoverIn(bSaveHeader);
	}

	// Event Listener on Button[#bSaveHeader].onMouseExited
	@FXML
	public void bSaveHeaderMouseExit(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gpModifyBottomButtonHoverOut(bSaveHeader);
	}

	// Event Listener on Button[#bSaveHeader].onMousePressed
	@FXML
	public void bSaveHeaderMousePressed(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gpModifyBottomButtonPressed(bSaveHeader);
	}

	// Event Listener on Button[#bSaveHeader].onMouseReleased
	@FXML
	public void bSaveHeaderMouseReleased(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gbModifyBottomButtonReleased(bSaveHeader);
	}

	// Event Listener on Button[#bSaveLine].onAction
	@FXML
	public void saveServicesSaleOrderLine(ActionEvent event) {
		// TODO Autogenerated
		
		// VALIDATE SERVICES SALES ORDER:
		if (IFormValidation.validateModifyServicesSalesOrderLine(cbService, cbProfitability, olServices, olProfitability, tfQuantity).isEmpty()) {
			modifyServiceSalesOrderLine();
			
			loadDataInTable();
		} else {
			// GET ERRORS:
			String errors = IFormValidation.validateModifyServicesSalesOrderLine(cbService, cbProfitability, olServices, olProfitability, tfQuantity);
			
			AlertMessage.showErrorAndWait(errors);
		}
	}

	// Event Listener on Button[#bSaveLine].onMouseEntered
	@FXML
	public void bSaveLineMouseEntered(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gpModifyBottomButtonHoverIn(bSaveLine);
	}

	// Event Listener on Button[#bSaveLine].onMouseExited
	@FXML
	public void bSaveLineMouseExit(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gpModifyBottomButtonHoverOut(bSaveLine);
	}

	// Event Listener on Button[#bSaveLine].onMousePressed
	@FXML
	public void bSaveLineMousePressed(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gpModifyBottomButtonPressed(bSaveLine);
	}

	// Event Listener on Button[#bSaveLine].onMouseReleased
	@FXML
	public void bSaveLineMouseReleased(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gbModifyBottomButtonReleased(bSaveLine);
	}

	// Event Listener on Button[#bSaveLineClose].onAction
	@FXML
	public void saveCloseServicesSaleOrderLine(ActionEvent event) {
		// TODO Autogenerated
		
		// VALIDATE SERVICES SALES ORDER:
		if (IFormValidation.validateModifyServicesSalesOrderLine(cbService, cbProfitability, olServices, olProfitability, tfQuantity).isEmpty()) {
			modifyServiceSalesOrderLine();
			
			loadDataInTable();
			
			// CLOSE WINDOW:
			Stage stage = (Stage) this.bClose.getScene().getWindow();

			stage.close();
		} else {
			// GET ERRORS:
			String errors = IFormValidation.validateModifyServicesSalesOrderLine(cbService, cbProfitability, olServices, olProfitability, tfQuantity);
			
			AlertMessage.showErrorAndWait(errors);
		}
	}

	// Event Listener on Button[#bSaveLineClose].onMouseEntered
	@FXML
	public void bSaveLineCloseMouseEntered(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gpModifyBottomButtonHoverIn(bSaveLineClose);
	}

	// Event Listener on Button[#bSaveLineClose].onMouseExited
	@FXML
	public void bSaveLineCloseMouseExit(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gpModifyBottomButtonHoverOut(bSaveLineClose);
	}

	// Event Listener on Button[#bSaveLineClose].onMousePressed
	@FXML
	public void bSaveLineCloseMousePressed(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gpModifyBottomButtonPressed(bSaveLineClose);
	}

	// Event Listener on Button[#bSaveLineClose].onMouseReleased
	@FXML
	public void bSaveLineCloseMouseReleased(MouseEvent event) {
		// TODO Autogenerated

		IFormWindow.gbModifyBottomButtonReleased(bSaveLineClose);
	}

	// ----------------------------------------------------------------------------------------

	// Event Listener on DatePicker[#dpDate].onAction
	@FXML
	public void verifyDpSaleOrderDate(ActionEvent event) {
		// TODO Autogenerated

		if (dpDate.getValue() != null) {
			dpDate.setStyle("-fx-border-color: blueviolet;");
		}
	}

	// Event Listener on ComboBox[#cbCompany].onAction
	@FXML
	public void getCompany(ActionEvent event) {
		// TODO Autogenerated

		IFormWindow.checkModifyCbIsSelected(cbCompany, olCompany);
	}

	// Event Listener on ComboBox[#cbCustomer].onAction
	@FXML
	public void getCustomer(ActionEvent event) {
		// TODO Autogenerated

		IFormWindow.checkModifyCbIsSelected(cbCustomer, olCustomer);
	}

	// Event Listener on ComboBox[#cbService].onAction
	@FXML
	public void getService(ActionEvent event) {
		// TODO Autogenerated

		IFormWindow.checkModifyCbIsSelected(cbService, olServices);
	}

	// Event Listener on ComboBox[#cbProfitability].onAction
	@FXML
	public void getProfitability(ActionEvent event) {
		// TODO Autogenerated

		IFormWindow.checkModifyCbIsSelected(cbProfitability, olProfitability);
	}

	// Event Listener on ComboBox[#cbCompany].onKeyReleased
	@FXML
	public void filterCompany(KeyEvent event) {
		// TODO Autogenerated
		String filter = this.cbCompany.getEditor().getText();

		IFormWindow.filterString(filter, cbCompany, olCompany);
	}

	// Event Listener on ComboBox[#cbCustomer].onKeyReleased
	@FXML
	public void filterCustomer(KeyEvent event) {
		// TODO Autogenerated

		String filter = this.cbCustomer.getEditor().getText();

		IFormWindow.filterString(filter, cbCustomer, olCustomer);
	}

	// Event Listener on ComboBox[#cbService].onKeyReleased
	@FXML
	public void filterService(KeyEvent event) {
		// TODO Autogenerated

		String filter = this.cbService.getEditor().getText();

		IFormWindow.filterString(filter, cbService, olServices);
	}

	// Event Listener on ComboBox[#cbProfitability].onKeyReleased
	@FXML
	public void filterProfitability(KeyEvent event) {
		// TODO Autogenerated
		String filter = this.cbProfitability.getEditor().getText();

		IFormWindow.filterString(filter, cbProfitability, olProfitability);
	}

	// Event Listener on TextField[#tfQuantity].onKeyReleased
	@FXML
	public void typeQuantity(KeyEvent event) {
		// TODO Autogenerated

		if (IFormWindow.checkNumberTextField(tfQuantity)) {
			this.tfQuantity.setStyle("-fx-border-color: blueviolet;");
		} else {
			this.tfQuantity.setStyle("-fx-border-color: red;");
		}
	}
	
	// Event Listener on TableView[#tRecord].onMouse
	@FXML
	public void getRecord(MouseEvent event) {
		// TODO Autogenerated
		
		TableViewSelectionModel<ServicesSalesOrder> ssoModel = this.tRecord.getSelectionModel();
		ServicesSalesOrder sso = this.tRecord.getSelectionModel().getSelectedItem();
		
		// System.out.println("hola que pasa");
		
		if(sso != null || !ssoModel.isEmpty()) {
			// System.out.println("It isn't null or empty.");
			
			tfOrderLineNumber.setText(sso.getLineId() + "");
			cbService.setValue(sso.getServiceName());
			cbProfitability.setValue(sso.getProfitabilityPercentage() + "");
			tfQuantity.setText(Integer.parseInt(sso.getQuantity() + "") + "");
		}
	}
	
	// UPDATE SERVICES SALES ORDER LINE:
	public void modifyServiceSalesOrderLine() {
		// OBJECTS FOR COMBOBOXES:
		String sService = cbService.getEditor().getText();
		String sProfitability = cbProfitability.getEditor().getText();
		Service s = new Service();
		ServiceProfitability sp = new ServiceProfitability();

		s.setName(sService);
		sp.setPercentage(Integer.parseInt(sProfitability));

		// GET ID FROM SERVICE AND PROFITABILITY:
		int serviceId = s.getServiceIdWithName();
		int serviceProfitabilityId = sp.getProfitabilityIdWithPercentage();

		// MAKE OBJECT ServicesSalesOrder:
		ServicesSalesOrder sso = new ServicesSalesOrder();

		// SET VALUES TO UPATE LINEID:
		sso.setOrderId(Integer.parseInt(tfOrderNumber.getText()));
		sso.setLineId(Integer.parseInt(tfOrderLineNumber.getText()));
		sso.setServiceId(serviceId);
		sso.setProfitabilityId(serviceProfitabilityId);
		sso.setQuantity(Integer.parseInt(tfQuantity.getText()));

		// UPDATE OBJECT:
		if (sso.updateServicesSalesOrderLine()) {
			AlertMessage.showInformationCorrectUpdateAndWait(sso.getRows());
		} else {
			AlertMessage.showErrorAndWait("Ocurri� un error durante la modificaci�n del registro.");
		}
	}
}
