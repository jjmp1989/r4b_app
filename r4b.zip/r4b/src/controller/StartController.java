package controller;

import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class StartController {
	public void startApp(BorderPane root, Scene s, Stage ps) {
		Image imgLogo = new Image("File:resources/media/images/logo_high_quality.png");
		ImageView ivLogo = new ImageView(imgLogo);
		Label lLogo = new Label("", ivLogo);
		FadeTransition ft = new FadeTransition();

		ft.setDuration(Duration.millis(3000));
		ft.setFromValue(10);
		ft.setToValue(0);
		ft.setNode(lLogo);

		ft.play();

		ivLogo.setFitWidth(400);
		ivLogo.setFitHeight(375);

		root.setCenter(lLogo);
		
		PauseTransition pause = new PauseTransition(Duration.millis(3200));
		pause.setOnFinished(event -> openLogin());
		pause.play();
	}
	
	public void openLogin() {
		try {
			Stage stage = new Stage();
			Parent parent = FXMLLoader.load(getClass().getResource("/views/PaneLogin.fxml"));
			Scene scene = new Scene(parent);

			stage.setScene(scene);
			stage.setTitle("Acceso");
			stage.getIcons().add(new Image("File:resources/media/images/small_logo.png"));
			stage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
