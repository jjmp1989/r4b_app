package r4b_ddbb_management;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class ConnectionDb {
	private String nameClass = "com.mysql.cj.jdbc.Driver";
	private String subprotocol = "jdbc:mysql://";
	private String host;
	private String database = "third_factor_lts";
	private String user;
	private String password;
	private static Connection c;
	private boolean isConnected = false;

	// CONSTRUCTOR:
	public ConnectionDb(String host, String user, String password) {
		this.host = host;
		this.user = user;
		this.password = password;

		try {
			Class.forName(nameClass);

			c = DriverManager.getConnection(subprotocol + this.host + "/" + database, this.user, this.password);

			isConnected = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block

			if (e.getErrorCode() == 1045) {
				JOptionPane.showInternalMessageDialog(null, "Usuario y/o contrase�a incorrecto/s.", "Error", 0);
			} else {
				JOptionPane.showInternalMessageDialog(null,
						"C�digo de error: " + e.getErrorCode() + "\nError en la conexi�n.", "Error", 0);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			
			JOptionPane.showInternalMessageDialog(null, "Clase Driver No encontrada.", "Error", 0);
		}
	}

	// GET CONNECTION:
	public Connection getC() {
		return c;
	}

	// KNOW IF IT IS CONNECTED:
	public boolean getIsConnected() {
		return isConnected;
	}

	// CLASE CONNECTION:
	public static void closeConnection() {
		if (c != null) {
			try {
				c.close();
			} catch (SQLException e) {
				JOptionPane.showInternalMessageDialog(null, "Error al cerrar la conexi�n.", "Error", 0);
			}
		}
	}
}
