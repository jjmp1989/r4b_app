package model;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataSelector;

public class GoodsSalesOutput {
	// ATTRIBUTES FOR TABLE goods_sales_output_header;
	private int outputId;
	private int orderId;
	private Date outputDate;

	// ATTRIBUTES FOR VIEW v_goods_sales_output_header;
	private String companyName;
	private String businessPartnerName;

	// ATTRIBUTES FOR TABLE goods_sales_output_lines;

	// ATTRIBUTES FOR VIEW v_goods_sales_output_header;

	// CONSTRUCTOR BY DEFAULT:
	public GoodsSalesOutput() {

	}

	// CONSTRUCTOR FOR TABLE services_sales_output_header:
	public GoodsSalesOutput(int outputId, int orderId, Date outputDate) {
		super();
		this.outputId = outputId;
		this.orderId = orderId;
		this.outputDate = outputDate;
	}

	// CONSTRUCTOR FOR VIEW v_services_sales_output_header;
	public GoodsSalesOutput(int outputId, int orderId, String companyName, String businessPartnerName, Date outputDate) {
		super();
		this.outputId = outputId;
		this.orderId = orderId;
		this.companyName = companyName;
		this.businessPartnerName = businessPartnerName;
		this.outputDate = outputDate;
	}

	public int getOutputId() {
		return outputId;
	}

	public void setOutputId(int outputId) {
		this.outputId = outputId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public Date getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(Date outputDate) {
		this.outputDate = outputDate;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBusinessPartnerName() {
		return businessPartnerName;
	}

	public void setBusinessPartnerName(String businessPartnerName) {
		this.businessPartnerName = businessPartnerName;
	}

	// SHOW services sales outputs IN TABLE OF VIEW ServicesSalesOutput.fxml:
	public ObservableList<GoodsSalesOutput> getGoodsSalesOutput() {
		ObservableList<GoodsSalesOutput> obs = FXCollections.observableArrayList();

		try {
			// INSTANCE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQuery("select * from v_goods_output_header");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				outputId = rs.getInt(1);
				orderId = rs.getInt(2);
				companyName = rs.getString(3);
				businessPartnerName = rs.getString(4);
				outputDate = rs.getDate(5);

				// INSTANCE OBJECT GoodsSalesOutput:
				GoodsSalesOutput gso = new GoodsSalesOutput(outputId, orderId, companyName, businessPartnerName,
						outputDate);

				obs.add(gso);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();
			
			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los datos en la tabla.");
		}

		// RETURN ObservableList:
		return obs;
	}
}
