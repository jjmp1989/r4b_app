DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `check_services_sales_order_number`(order_number INT)
BEGIN
	IF EXISTS(SELECT id FROM services_sales_orders_header WHERE id = order_number) THEN
		SELECT 1 AS order_number_exist;
	ELSE
		SELECT 0 AS order_number_exist;
	END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_business_partner`()
BEGIN
	SELECT
		`business_partner_header`.`id`,
        `business_partner_header`.`cif`,
        `business_partner_header`.`name`,
        `business_partner_header`.`is_customer`,
        `business_partner_header`.`is_supplier`,
        `business_partner_details`.`natural_person`,
        `business_partner_details`.`address`,
        `business_partner_details`.`city`,
        `business_partner_details`.`province`,
        `business_partner_details`.`postcode`,
        `business_partner_details`.`country`
    FROM `business_partner_header`
    LEFT JOIN `business_partner_details`
    ON `business_partner_header`.`id` = `business_partner_details`.`business_partner_header_id`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_business_partner_details_with_id`(p_bp_id INT)
BEGIN
	SELECT natural_person, address, city, province, postcode, country FROM business_partner_details WHERE business_partner_header_id = p_bp_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_business_partner_id_with_cif`(p_cif VARCHAR(15))
BEGIN
	SELECT id FROM business_partner_header AS bph WHERE bph.cif = p_cif;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_business_partner_id_with_name`(business_partner_name VARCHAR(25))
BEGIN
	SELECT `id` FROM business_partner_header WHERE `name` = business_partner_name;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_companies`()
BEGIN
	SELECT
		`companies_header`.`id`,
        `companies_header`.`cif`,
        `companies_header`.`name`,
        `companies_details`.`natural_person`,
        `companies_details`.`address`,
        `companies_details`.`city`,
        `companies_details`.`province`,
        `companies_details`.`postcode`,
        `companies_details`.`country`
    FROM `companies_header`
    LEFT JOIN `companies_details`
    ON `companies_header`.`id` = `companies_details`.`companies_header_id`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_company_details_with_id`(company_id INT)
BEGIN
	SELECT natural_person, address, city, province, postcode, country FROM companies_details WHERE companies_header_id = company_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_company_id_with_cif`(p_cif VARCHAR(15))
BEGIN
	SELECT id FROM companies_header AS ch WHERE ch.cif = p_cif;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_company_id_with_name`(company_name VARCHAR(25))
BEGIN
	SELECT id FROM companies_header WHERE `name` = company_name;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_goods`()
BEGIN
	SELECT * FROM goods;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_goods_output`()
BEGIN
	SELECT goods_sales_output_header.id AS output_id, goods_sales_orders_header_id, goods_sales_output_lines.id AS line_id, goods_sales_order_lines_id, quantity
    FROM goods_sales_output_header
    LEFT JOIN goods_sales_output_lines ON goods_sales_output_header.id = goods_sales_output_lines.goods_sales_output_header_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_goods_profitabilities`()
BEGIN
	SELECT * FROM goods_profitability;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_goods_sales_orders`()
BEGIN
	SELECT gsoh.id AS order_id, business_partner_id, companies_header_id, gsol.id AS line_id, goods_id, goods_profitability_id, quantity
    FROM goods_sales_orders_header AS gsoh
    LEFT JOIN goods_sales_order_lines AS gsol
    ON gsoh.id = gsol.goods_sales_orders_header_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_goods_waste`()
BEGIN
	SELECT * FROM goods_waste;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_line_id_from_services_sales_order_with_service`(p_order_id INT, p_service_name VARCHAR(25))
BEGIN
	SELECT line_id FROM v_services_sales_order_lines WHERE sso_id = p_order_id AND service_name = p_service_name;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_measure_id_with_name`(measure_name VARCHAR(25))
BEGIN
	SELECT `id` FROM `measures` WHERE `name` = measure_name;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_measures`()
BEGIN
	SELECT * FROM `measures`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_next_services_sales_order_line_id`(services_sales_order_id INT)
BEGIN
	DECLARE lines_number INT;
    SET lines_number = (select max(id) from services_sales_order_lines where services_sales_orders_header_id = services_sales_order_id);
    
    IF lines_number IS NULL THEN
		SELECT 1;
	ELSE
		SELECT lines_number + 1;
    END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_next_services_sales_output_line_id`(p_services_sales_output_id INT)
BEGIN
	DECLARE next_line_number INT;
    SET next_line_number = (select max(id) from services_sales_output_lines where services_sales_output_header_id = p_services_sales_output_id);
    
    IF next_line_number IS NULL THEN
		SELECT 1;
	ELSE
		SELECT next_line_number + 1;
    END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_service_id_with_name`(service_name VARCHAR(25))
BEGIN
	SELECT `id` FROM `services` WHERE `name` = service_name;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_service_profitability_id_with_percentage`(p INT)
BEGIN
	SELECT `id` FROM `services_profitability` WHERE `percentage` = p;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_service_type`()
BEGIN
	SELECT * FROM `service_type`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_service_type_id_with_name`(name_service_type VARCHAR(25))
BEGIN
	SELECT id FROM service_type where service_type = name_service_type;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_services`()
BEGIN
	SELECT * FROM `services`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_services_from_sale_order`(order_id INT)
BEGIN
	SELECT service_name FROM v_services_sales_order_lines WHERE sso_id = order_id ORDER BY line_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_services_output`()
BEGIN
	SELECT ssoh.*, ssol.id AS id_lines, ssol.services_sales_order_lines_id, ssol.quantity
    FROM services_sales_output_header AS ssoh
    LEFT JOIN services_sales_output_lines AS ssol
    ON ssoh.id = ssol.services_sales_output_header_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_services_profitability`()
BEGIN
	SELECT * FROM `services_profitability`;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_services_sales_order_lines`(p_order_id INT)
BEGIN
	SELECT line_id, service_name, u_inventory_price, profitability_percentage, u_sale_price, quantity, total_sale_price FROM v_services_sales_order_lines WHERE sso_id = p_order_id ORDER BY line_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_services_sales_orders`()
BEGIN
	SELECT
		ssoh.id,
        ssoh.companies_header_id,
        ssoh.business_partner_header_id,
        ssol.id,
        ssol.services_id,
        ssol.services_profitability_id,
        ssol.quantity
	FROM services_sales_orders_header AS ssoh
    LEFT JOIN services_sales_order_lines AS ssol
    ON ssoh.id=ssol.services_sales_orders_header_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_services_sales_output_lines`(p_output_id INT)
BEGIN
	SELECT output_line_id, service_name, quantity FROM v_services_sales_output_lines WHERE output_id = p_output_id ORDER BY output_line_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_business_partner_details`(
	id INT,
    np BOOLEAN,
    a VARCHAR(40),
    c VARCHAR(25),
    p VARCHAR(25),
    pc VARCHAR(15),
    country VARCHAR(25)
)
BEGIN
	INSERT INTO `business_partner_details`(
		`business_partner_details`.`business_partner_header_id`,
		`business_partner_details`.`natural_person`,
		`business_partner_details`.`address`,
        `business_partner_details`.`city`,
        `business_partner_details`.`province`,
        `business_partner_details`.`postcode`,
        `business_partner_details`.`country`
	)
    VALUES(
		id,
		np,
        a,
        c,
        p,
        pc,
        country
    );
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_business_partner_header`(
	cif VARCHAR(15),
    n VARCHAR(25),
    c BOOLEAN,
    s BOOLEAN
)
BEGIN
	INSERT INTO `business_partner_header`(
		`business_partner_header`.`cif`,
		`business_partner_header`.`name`,
        `business_partner_header`.`is_customer`,
        `business_partner_header`.`is_supplier`
	)
    VALUES (
		cif,
        n,
        c,
        s
	);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_company_details`(
	id INT,
    np BOOLEAN,
    a VARCHAR(40),
    c VARCHAR(25),
    p VARCHAR(25),
    pc VARCHAR(15),
    country VARCHAR(25)
)
BEGIN
	INSERT INTO `companies_details`(
		`companies_details`.`companies_header_id`,
		`companies_details`.`natural_person`,
		`companies_details`.`address`,
        `companies_details`.`city`,
        `companies_details`.`province`,
        `companies_details`.`postcode`,
        `companies_details`.`country`
	)
    VALUES(
		id,
		np,
        a,
        c,
        p,
        pc,
        country
    );
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_company_header`(
	cif VARCHAR(15),
    n VARCHAR(25)
)
BEGIN
	INSERT INTO `companies_header`(
		`companies_header`.`cif`,
		`companies_header`.`name`
	)
    VALUES (
		cif,
        n
	);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods`(
	n VARCHAR(25),
    d VARCHAR(45),
    m INT
)
BEGIN
	INSERT INTO `goods`(
		`name`,
        `description`,
        `measures_id`
    )
    VALUES (
		n,
        d,
        m
	);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_output_header`(
	goh_id INT,
    output_d DATE
    )
BEGIN
	INSERT INTO goods_sales_output_header(
		goods_sales_orders_header_id,
        output_date)
	VALUES(
		goh_id,
        output_d);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_output_line`(
	g_output_h_id INT,
    g_order_l_id INT,
    q INT
)
BEGIN
	DECLARE line_id INT DEFAULT 0;
    
    SELECT MAX(id) FROM goods_sales_output_lines WHERE goods_sales_output_header_id = g_output_h_id INTO line_id;
    
    SET line_id = line_id + 1;
    
	IF line_id IS NULL THEN
		SET line_id = 1;
	END IF;
    
	INSERT INTO goods_sales_output_lines(
		id,
		goods_sales_output_header_id,
        goods_sales_order_lines_id,
        quantity
	)
    VALUES (
		line_id,
		g_output_h_id,
		g_order_l_id,
		q
    );
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_profitability`(p INT)
BEGIN
	INSERT INTO `goods_profitability`(percentage)
    VALUES (p);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_purchase_order_line`(
	gpoh_id INT,
    g_id INT,
    q INT,
    u_p FLOAT
)
BEGIN
    DECLARE t_price FLOAT;
    DECLARE line_id INT DEFAULT 0;
    
    SET line_id = (SELECT MAX(id) FROM goods_purchase_orders_line WHERE goods_purchase_orders_header_id = gpoh_id);
    
    SET line_id = line_id + 1;
    
	IF line_id IS NULL THEN
		SET line_id = 1;
	END IF;
    
    SET t_price = q * u_p;
    
	INSERT INTO goods_purchase_orders_line(
		id,
		goods_purchase_orders_header_id,
        goods_id,
        quantity,
        u_price,
        total_price
	)
    VALUES(
		line_id,
		gpoh_id,
        g_id,
        q,
        u_p,
        t_price
    );
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_purchase_orders_header`(
	c_id INT,
    bp_id INT,
    order_d DATE
)
BEGIN
	DECLARE bp_is_customer INT;
    
    SET bp_is_customer = (SELECT is_customer FROM business_partner_header WHERE id = bp_id);
    
    IF bp_is_customer = 1 THEN
		INSERT INTO goods_purchase_orders_header(
			companies_header_id,
			business_partner_id,
			order_date
		)
		VALUES(
			c_id,
			bp_id,
			order_d
		);
	END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_reception_header`(
	po_id INT,
    reception_d DATE
)
BEGIN
	INSERT INTO goods_reception_header(
		goods_orders_header_id,
        reception_date
	)
    VALUES(
		po_id,
        reception_d
	);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_reception_line`(
	grh_id INT,
    ol_id INT,
    q INT
)
BEGIN
    DECLARE line_id INT DEFAULT 0;
    DECLARE gpoh_id INT;
    DECLARE g_id INT;
	DECLARE inventory_quantity INT;
    DECLARE order_line_p_u FLOAT;
    
	SET line_id = (SELECT MAX(id) FROM goods_reception_line WHERE goods_reception_header_id = grh_id);
    
    SET line_id = line_id + 1;
    
	IF line_id IS NULL THEN
		SET line_id = 1;
	END IF;
    
    SET gpoh_id = (SELECT goods_orders_header_id FROM goods_reception_header WHERE id = grh_id);
    SET g_id = (SELECT goods_id FROM goods_purchase_orders_line WHERE id = ol_id AND goods_purchase_orders_header_id = gpoh_id);
    SET inventory_quantity = (SELECT quantity FROM goods WHERE id = g_id);
    SET order_line_p_u = (SELECT u_price FROM goods_purchase_orders_line WHERE id = ol_id AND goods_purchase_orders_header_id = gpoh_id);
    
	INSERT INTO goods_reception_line(
		id,
		goods_reception_header_id,
        goods_id,
        quantity
    )
    VALUES(
		line_id,
		grh_id,
		ol_id,
		q
    );
    
    UPDATE goods
	SET quantity = inventory_quantity + q
	WHERE id = g_id;
    
	UPDATE goods
	SET wacc_value = wacc_value + (order_line_p_u * q)
	WHERE id = g_id;
    
	UPDATE goods
	SET u_price_wacc = wacc_value / quantity
	WHERE id = g_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_sales_order_header`(
	p_id_company int,
    p_bp_id INT,
    p_order_d DATE
)
BEGIN
	DECLARE bp_is_customer INT;
    
    SET bp_is_customer = (SELECT is_customer FROM business_partner_header WHERE id = p_bp_id);
    
    IF bp_is_customer = 1 THEN
		INSERT INTO goods_sales_orders_header(companies_header_id, business_partner_id, order_date)
		VALUES (p_id_company, p_bp_id, p_order_d);
	END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_sales_order_line`(
	gsoh_id INT,
    g_id INT,
    p_id INT,
    q INT
)
BEGIN
	DECLARE line_id INT DEFAULT 0;
    DECLARE good_stock INT;
    DECLARE enough_stock BOOLEAN;
    
    SELECT MAX(id) FROM goods_sales_order_lines WHERE goods_sales_orders_header_id = gsoh_id INTO line_id;
    
    SET good_stock = (SELECT quantity FROM goods WHERE id = g_id);
    SET line_id = line_id + 1;
    
	IF good_stock >= q THEN
		SET enough_stock = TRUE;
	ELSE
		SET enough_stock = FALSE;
	END IF;
    
	IF enough_stock = TRUE THEN
		IF line_id IS NULL THEN
			SET line_id = 1;
		END IF;
    
		INSERT INTO goods_sales_order_lines(
			id,
			goods_sales_orders_header_id,
			goods_id,
			goods_profitability_id,
			quantity
		)
		VALUES(
			line_id,
			gsoh_id,
			g_id,
			p_id,
			q
		);
        
		UPDATE goods
		SET quantity = quantity - q
		WHERE id = g_id;
	ELSE
		SELECT enough_stock AS enough_stock;
	END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_goods_waste`(
	yr INT,
    g_id INT,
    q INT,
    is_finished BOOLEAN
)
BEGIN
	INSERT INTO `goods_waste`(
		`year`,
        `goods_id`,
        `quantity`,
        `finished`
	)
    VALUES (
		yr,
        g_id,
        q,
        is_finished
	);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_measure`(n VARCHAR(25))
BEGIN
	INSERT INTO `measures`(`name`)
    VALUES (n);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_service`(
	id_st INT,
    id_m INT,
    n VARCHAR(25),
    d VARCHAR(40),
    up FLOAT
)
BEGIN
	INSERT INTO `services`(`service_type_id`,
		`measure_id`,
        `name`,
        `description`,
        `u_price`
	)
    VALUES (id_st, id_m, n, d, up);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_service_profitability`(p INT)
BEGIN
	INSERT INTO `services_profitability`(`percentage`)
    VALUES (p);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_service_type`(
	st VARCHAR(25),
    d VARCHAR(40)
)
BEGIN
	INSERT INTO `service_type`(`service_type`, `description`)
    VALUES (st, d);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_services_sales_order_header`(
	c INT,
    bp INT,
    d DATE
)
BEGIN
	DECLARE bp_is_customer INT;
    
    SET bp_is_customer = (SELECT is_customer FROM business_partner_header WHERE id = bp);
    
    IF bp_is_customer = 1 THEN
		INSERT INTO services_sales_orders_header (
			companies_header_id,
			business_partner_header_id,
			order_date
		)
		VALUES (
			c,
			bp,
			d
		);
	END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_services_sales_orders_lines`(
	o_id INT,
    s INT,
    p INT,
    q INT
)
BEGIN
	DECLARE line_id INT DEFAULT 0;
    
    SELECT MAX(id) FROM services_sales_order_lines WHERE services_sales_orders_header_id = o_id INTO line_id;
    
    SET line_id = line_id + 1;
    
    IF line_id IS NULL THEN
		SET line_id = 1;
	END IF;

	INSERT INTO services_sales_order_lines(
		id,
		services_sales_orders_header_id,
		services_id,
        services_profitability_id,
        quantity
	)
    VALUES (
		line_id,
		o_id,
		s,
        p,
        q
	);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_ss_output_header`(
	ss_order_header_id INT,
    output_d DATE
)
BEGIN
	INSERT INTO services_sales_output_header(
		services_sales_orders_header_id,
        output_date
	)
	VALUES(
		ss_order_header_id,
        output_d
	);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert_ss_output_lines`(
	ss_output_header_id INT,
    ss_order_line_id INT,
    q INT
)
BEGIN
	DECLARE line_id INT DEFAULT 0;
    
    SELECT MAX(id) FROM services_sales_output_lines WHERE services_sales_output_header_id = ss_output_header_id INTO line_id;
    
    SET line_id = line_id + 1;
    
	IF line_id IS NULL THEN
		SET line_id = 1;
	END IF;
    
	INSERT INTO services_sales_output_lines(
		id,
		services_sales_output_header_id,
        services_sales_order_lines_id,
        quantity
	)
    VALUES(
		line_id,
		ss_output_header_id,
		ss_order_line_id,
        q
	);
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `pruebas`(
o_id INT,
	s INT,
    p INT,
    q INT
)
BEGIN
DECLARE line_id INT DEFAULT 0;
    
    SELECT MAX(id) FROM services_sales_order_lines WHERE services_sales_orders_header_id = o_id INTO line_id;
    
    SET line_id = line_id + 1;
    
    SELECT LINE_ID;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_business_partner_details`(
	id INT,
    np BOOLEAN,
    a VARCHAR(45),
    c VARCHAR(25),
    p VARCHAR(25),
    pc VARCHAR(15),
    country VARCHAR(25)
)
BEGIN
    UPDATE `business_partner_details`
    SET
        `business_partner_details`.`natural_person` = np,
        `business_partner_details`.`address` = a,
        `business_partner_details`.`city` = c,
        `business_partner_details`.`province` = p,
        `business_partner_details`.`postcode` = pc,
        `business_partner_details`.`country` = country
	WHERE `business_partner_details`.`business_partner_header_id` = id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_business_partner_header`(
	id INT,
    cif VARCHAR(15),
    n VARCHAR(25),
    customer BOOLEAN,
    supplier BOOLEAN
)
BEGIN
	UPDATE `business_partner_header`
    SET
        `business_partner_header`.`cif` = cif,
        `business_partner_header`.`name` = n,
        `business_partner_header`.`is_customer` = customer,
        `business_partner_header`.`is_supplier` = supplier
	WHERE `business_partner_header`.`id` = id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_company_details`(
	c_id INT,
    np BOOLEAN,
    a VARCHAR(45),
    c VARCHAR(25),
    p VARCHAR(25),
    pc VARCHAR(15),
    country VARCHAR(25)
)
BEGIN
    UPDATE `companies_details`
    SET
        `companies_details`.`natural_person` = np,
        `companies_details`.`address` = a,
        `companies_details`.`city` = c,
        `companies_details`.`province` = p,
        `companies_details`.`postcode` = pc,
        `companies_details`.`country` = country
	WHERE `companies_details`.`companies_header_id` = c_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_company_header`(
	id INT,
    cif VARCHAR(15),
    n VARCHAR(25)
)
BEGIN
	UPDATE `companies_header`
    SET
        `companies_header`.`cif` = cif,
        `companies_header`.`name` = n
	WHERE `companies_header`.`id` = id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_goods`(
	id_good INT,
	n VARCHAR(25),
    d VARCHAR(45),
    m INT
)
BEGIN
	UPDATE `goods`
    SET
		`name` = n,
        `description` = d,
        `id_measure` = m
	WHERE `id` = id_good;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_goods_sales_order`(
	order_id INT,
    bp_id INT,
    line_id INT,
    g_id INT,
    p_id INT,
    q INT
)
BEGIN
	DECLARE bp_is_customer INT;
    
    SET bp_is_customer = (SELECT is_customer FROM business_partner_header WHERE id = bp_id);
    
	IF bp_is_customer = 1 THEN
		UPDATE goods_sales_orders_header
		SET business_partner_id = bp_id
		WHERE id = order_id;
	END IF;
    
    UPDATE goods_sales_order_lines
    SET goods_id = g_id, profitability_id = p_id, quantity = q
    WHERE id = line_id AND goods_sales_orders_header_id = order_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_goods_sales_output`(
	output_id INT,
    g_sales_order_header_id INT,
    line_id INT,
    sales_order_line_id INT,
    q INT
)
BEGIN
	UPDATE goods_output_header
	SET goods_orders_header_id = g_sales_order_header_id
	WHERE id = output_id;
    
    UPDATE goods_output_lines
    SET goods_order_lines_id = sales_order_line_id, quantity = q
    WHERE id = line_id AND goods_output_header_id = output_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_goods_waste`(
	yr INT,
    g_id INT,
    q INT,
    is_finished BOOLEAN
)
BEGIN
	UPDATE `goods_waste`
    SET
        `quantity` = q,
        `finished` = is_finished
	WHERE `year` = yr AND `goods_id` = g_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_measure`(id INT, n VARCHAR(20))
BEGIN
	UPDATE `measures`
    SET `name` = n
    WHERE measures.id = id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_profitabilities`(id_prof INT, p INT)
BEGIN
	UPDATE `profitability`
	SET `percentage` = p
    WHERE `id` = id_prof;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_service`(
	id INT,
    id_st INT,
    id_m INT,
    n VARCHAR(20),
    d VARCHAR(40),
    up FLOAT
)
BEGIN
	UPDATE `services`
    SET
		`service_type_id` = id_st,
		`measure_id` = id_m,
        `name` = n,
        `description` = d,
        `u_price` = up
    WHERE services.id = id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_service_type`(
	id INT,
	st VARCHAR(25),
    d VARCHAR(40)
)
BEGIN
	UPDATE `service_type`
    SET
		`service_type`=st,
		`description`=d
	WHERE service_type.id = id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_services_profitability`(id INT, p INT)
BEGIN
	UPDATE `services_profitability`
    SET `percentage` = p
    WHERE services_profitability.id = id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_services_sales_order_details`(
	order_id INT,
	line_id INT,
	services_id INT,
    profitability_id INT,
	quantity INT
)
BEGIN
    UPDATE services_sales_order_lines AS ssol
    SET
        ssol.services_id = services_id,
        ssol.services_profitability_id = profitability_id,
        ssol.quantity = quantity
	WHERE ssol.services_sales_orders_header_id = order_id AND ssol.id = line_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_services_sales_order_header`(
	id_order INT,
	company_id INT,
	business_partner_id INT,
    order_date DATE
)
BEGIN
	UPDATE services_sales_orders_header AS ssoh
    SET
		ssoh.companies_header_id = company_id,
		ssoh.business_partner_header_id = business_partner_id,
        ssoh.order_date = order_date
	WHERE ssoh.id = id_order;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_services_sales_output_details`(
	output_header_id INT,
	line_id INT,
    ss_order_lines_id INT,
	q INT
)
BEGIN
    DECLARE order_id INT;
	DECLARE exists_order_line_id BOOLEAN;
    
    SET order_id = (SELECT services_sales_orders_header_id FROM services_sales_output_header WHERE id = output_header_id);
    SET exists_order_line_id = (SELECT EXISTS (SELECT * FROM services_sales_order_lines WHERE services_sales_orders_header_id = order_id AND id = ss_order_lines_id));

	IF exists_order_line_id THEN
		UPDATE services_sales_output_lines AS ssol
		SET
			ssol.services_sales_output_header_id = output_header_id,
			ssol.services_sales_order_lines_id = ss_order_lines_id,
			ssol.quantity = q
		WHERE ssol.services_sales_output_header_id = output_header_id AND ssol.id = line_id;
        
        -- SELECT 'IT IS UPDATED';
	-- ELSE
		-- SELECT 'IT IS NOT UPDATED';
	END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_services_sales_output_header`(
	output_header_id INT,
	ss_orders_header_id INT,
    output_date DATE
)
BEGIN
	DECLARE exists_lines BOOLEAN;
    
    SET exists_lines = (SELECT EXISTS(SELECT * FROM `services_sales_output_lines` WHERE `services_sales_output_header_id` = output_header_id));
    
	IF exists_lines = 0 THEN
		UPDATE services_sales_output_header AS ssoh
		SET
			ssoh.services_sales_orders_header_id = ss_orders_header_id,
			ssoh.output_date = output_date
		WHERE ssoh.id = output_header_id;
	END IF;
END$$
DELIMITER ;
