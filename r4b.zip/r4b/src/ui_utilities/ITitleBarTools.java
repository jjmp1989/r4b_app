package ui_utilities;

import java.util.Optional;

import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DialogPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;
import r4b_ddbb_management.DatabaseSecurity;

public interface ITitleBarTools {
	public static double[] gridPaneTitleBarPressed(MouseEvent e, Stage s) {
		// TAKE COORDINATE:
		double x1 = e.getScreenX();
		double y1 = e.getScreenY();
		double x_stage = s.getX();
		double y_stage = s.getY();

		double[] list = { x1, y1, x_stage, y_stage };

		return list;
	}

	public static void gridPaneTitleBarDragged(MouseEvent e, Stage s, GridPane gp, double[] list) {
		// CHANGE CURSOR IN MOVING:
		gp.setCursor(Cursor.MOVE);

		// CALCULE NEW POSITION:
		s.setX(list[2] + e.getScreenX() - list[0]);
		s.setY(list[3] + e.getScreenY() - list[1]);
	}

	public static void gridPaneTitleBarMouseReleased(MouseEvent e, Stage s, GridPane gp) {
		// CHANGE CURSOR WHEN MOVING FINISH:
		gp.setCursor(Cursor.DEFAULT);
	}

	public static void closeButtonCloseWindow(Stage stage, Button bClose) {
		/* ESTO SE HACIA ASI ANTES, PERO DE ESTA MANERA NO SE BORRAN LOS ARCHIVOS TEMPORALES DE LA BBDD: 
		 * 
		 * bClose.setTextFill(Color.DARKRED); bClose.setStyle(
		 * "-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: darkred; -fx-background-color: TRANSPARENT;"
		 * );
		 * 
		 * Alert alert = new Alert(AlertType.CONFIRMATION); alert.initOwner(stage);
		 * alert.initModality(Modality.WINDOW_MODAL); alert.setTitle("Confirme");
		 * alert.setHeaderText("�Salir?"); alert.setContentText("�Est� seguro?");
		 * alert.getDialogPane();
		 * 
		 * Optional<ButtonType> result = alert.showAndWait();
		 * 
		 * if (!result.isPresent() || result.get() == ButtonType.OK) { stage.close(); }
		 * else { bClose.setStyle(
		 * "-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: red; -fx-background-color: TRANSPARENT;"
		 * ); bClose.setTextFill(Color.RED); }
		 */

		Alert alert = new Alert(AlertType.CONFIRMATION);
		CheckBox cbDeleteFiles = new CheckBox();

		bClose.setTextFill(Color.DARKRED);
		bClose.setStyle(
				"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: darkred; -fx-background-color: TRANSPARENT;");

		alert.initOwner(stage);
		alert.initModality(Modality.WINDOW_MODAL);
		alert.getDialogPane().applyCss();
		Node graphic = alert.getDialogPane().getGraphic();
		
		alert.setDialogPane(new DialogPane() {
			@Override
			protected Node createDetailsButton() {
				cbDeleteFiles.setText("Eliminar archivos temporales BBDD.");
				return cbDeleteFiles;
			}
		});

		alert.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
		alert.getDialogPane().setExpandableContent(new Group());
		alert.getDialogPane().setGraphic(graphic);
		alert.setTitle("Confirme");
		alert.setHeaderText("�Salir?");
		alert.getDialogPane().setContentText("�Est� seguro?");
		alert.getDialogPane();

		Optional<ButtonType> result = alert.showAndWait();

		if (!result.isPresent() || result.get() == ButtonType.OK) {
			if (cbDeleteFiles.isSelected()) {
				DatabaseSecurity dbs = new DatabaseSecurity();

				dbs.deleteSecurityFiles();
			}

			stage.close();
		} else {
			bClose.setStyle(
					"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: red; -fx-background-color: TRANSPARENT;");
			bClose.setTextFill(Color.RED);
		}
	}

	public static void closeButtonHoverIn(Button bClose) {
		bClose.setStyle(
				"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: fuchsia; -fx-background-color: TRANSPARENT;");
		bClose.setTextFill(Color.FUCHSIA);
	}

	public static void closeButtonHoverOut(Button bClose) {
		bClose.setStyle(
				"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: red; -fx-background-color: TRANSPARENT;");
		bClose.setTextFill(Color.RED);
	}

	public static void minimiseButtonMinimiseWindow(Stage s) {
		s.setIconified(true);
	}

	public static void minimiseButtonHoverIn(Button bMinimise) {
		bMinimise.setStyle(
				"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: yellow; -fx-background-color: TRANSPARENT;");
		bMinimise.setTextFill(Color.YELLOW);
	}

	public static void minimiseButtonHoverOut(Button bMinimise) {
		bMinimise.setStyle(
				"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: goldenrod; -fx-background-color: TRANSPARENT;");
		bMinimise.setTextFill(Color.GOLDENROD);
	}

	public static void changeSizeButtonChangeSize(Stage s, Button bChangeSize) {
		if (!s.isFullScreen()) {
			s.setFullScreen(true);

			bChangeSize.setStyle(
					"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: orangered; -fx-background-color: TRANSPARENT;");
			bChangeSize.setTextFill(Color.ORANGERED);
		} else {
			s.setFullScreen(false);

			bChangeSize.setStyle(
					"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: green; -fx-background-color: TRANSPARENT;");
			bChangeSize.setTextFill(Color.GREEN);
		}
	}

	public static void changeSizeButtonHoverIn(Button bChangeSize) {
		bChangeSize.setStyle(
				"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: limegreen; -fx-background-color: TRANSPARENT;");
		bChangeSize.setTextFill(Color.LIMEGREEN);
	}

	public static void changeSizeButtonHoverOut(Button bChangeSize) {
		bChangeSize.setStyle(
				"-fx-background-radius: 5em; -fx-border-radius: 5em; -fx-border-color: green; -fx-background-color: TRANSPARENT;");
		bChangeSize.setTextFill(Color.GREEN);
	}
}
