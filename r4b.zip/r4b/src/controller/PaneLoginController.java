package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import alert_messages.AlertMessage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DatabaseSecurity;

public class PaneLoginController implements Initializable {
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

	@FXML
	private AnchorPane apRoot;
	@FXML
	private Button bAccess;
	@FXML
	private TextField tfUser;
	@FXML
	private TextField pfPassword;

	@FXML
	public void goMainMenu(ActionEvent e) throws Exception {
		ConnectionDb cdb = new ConnectionDb("localhost", tfUser.getText(), pfPassword.getText());

		cdb.getC();

		if (cdb.getIsConnected()) {
			DatabaseSecurity dbs = new DatabaseSecurity();
			dbs.makeSecurityFiles(tfUser.getText(), pfPassword.getText());

			ConnectionDb.closeConnection();

			if (e.getSource() == bAccess) {
				openMainMenu();
			}
		} else {
			ConnectionDb.closeConnection();
		}
	}

	public void openMainMenu() {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/MainMenu.fxml"));
			Parent root = loader.load();
			Scene s = new Scene(root);
			Stage stage = new Stage();
			Stage stageLogin;

			stage.initStyle(StageStyle.UNDECORATED);
			stage.setScene(s);
			stage.show();

			stageLogin = (Stage) this.bAccess.getScene().getWindow();

			stageLogin.close();
		} catch (IOException ioe) {
			// ioe.printStackTrace();

			AlertMessage.showErrorAndWait("La vista  no pudo ser cargada. Existe un problema con el archivo fxml.");
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("La vista  no pudo ser cargada.");
		}
	}
}
