package styles;

import javafx.scene.control.Label;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;

public class InitializableStyle {
	public static void InitializeStyleFormWindow(Label lTitle, BorderPane bpWorkView, GridPane gpBottom) {
		Stop[] stops = new Stop[] { new Stop(0, Color.WHITE), new Stop(1, Color.TRANSPARENT) };
		LinearGradient linear = new LinearGradient(0, 0, 1.7, 0, true, CycleMethod.NO_CYCLE, stops);
		LinearGradient linearLabelTitle = new LinearGradient(0, 0, 1, 0, true, CycleMethod.NO_CYCLE, stops);
		BackgroundFill bgf = new BackgroundFill(linear, null, null);
		BackgroundFill bgfLabelTitle = new BackgroundFill(linearLabelTitle, null, null);
		Background bg = new Background(bgf);
		Background bgLabelTitle = new Background(bgfLabelTitle);

		lTitle.setBackground(bgLabelTitle);

		bpWorkView.setBackground(bg);

		gpBottom.setBackground(bg);
	}
	
	public static void InitializeStyleFormWindowWithTable(Label lTitle, BorderPane bpWorkView) {
		Stop[] stops = new Stop[] { new Stop(0, Color.WHITE), new Stop(1, Color.TRANSPARENT) };
		LinearGradient linear = new LinearGradient(0, 0, 1.7, 0, true, CycleMethod.NO_CYCLE, stops);
		LinearGradient linearLabelTitle = new LinearGradient(0, 0, 1, 0, true, CycleMethod.NO_CYCLE, stops);
		BackgroundFill bgf = new BackgroundFill(linear, null, null);
		BackgroundFill bgfLabelTitle = new BackgroundFill(linearLabelTitle, null, null);
		Background bg = new Background(bgf);
		Background bgLabelTitle = new Background(bgfLabelTitle);

		lTitle.setBackground(bgLabelTitle);

		bpWorkView.setBackground(bg);
	}

	public static void initializeStyleWorkView(Label lTitle) {
		Stop[] stops = new Stop[] { new Stop(0, Color.TRANSPARENT), new Stop(1, Color.CYAN) };
		LinearGradient linear = new LinearGradient(0, 0, 1, 0, true, CycleMethod.NO_CYCLE, stops);
		BackgroundFill bgf = new BackgroundFill(linear, null, null);
		Background bg = new Background(bgf);

		lTitle.setBackground(bg);
	}
}
