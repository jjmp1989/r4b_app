package alert_messages;

import javafx.scene.control.Alert;

public class AlertMessage {
	public static void showErrorAndWait(String error) {
		Alert alert = new Alert(Alert.AlertType.ERROR);

		alert.setHeaderText(null);
		alert.setTitle("Error");
		alert.setContentText(error);
		alert.showAndWait();
	}
	
	public static void showInformationCorrectInsertAndWait(int  rows) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("�xito");
		alert.setContentText("Se insert� " + rows + " registro correctamente.");
		alert.showAndWait();
	}
	
	public static void showInformationCorrectUpdateAndWait(int  rows) {
		Alert alert = new Alert(Alert.AlertType.INFORMATION);
		alert.setHeaderText(null);
		alert.setTitle("�xito");
		alert.setContentText("Se modific� " + rows + " registro correctamente.");
		alert.showAndWait();
	}
}
