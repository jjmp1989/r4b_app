package ui_utilities;

import javafx.collections.ObservableList;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import model.ServicesSalesOrder;

public interface IFormValidation {
	// BUSINESS PARTNER:
	// METHOD TO VALIDATE ATTRIBUTES FOR BUSINESS PARTNER HEADER:
	public static String validateBusinessPartnerHeader(TextField tfCif, TextField tfName, CheckBox cbCustomer,
			CheckBox cbSupplier) {
		String errors = "";

		if (tfCif.getText().trim().isEmpty()) {
			errors += "- Debe indicar un CIF.\n";
		}

		if (tfName.getText().trim().isEmpty()) {
			errors += "- Debe indicar un nombre.\n";
		}

		if (!cbCustomer.isSelected() && !cbSupplier.isSelected()) {
			errors += "- El socio comercial debe ser cliente o proveedor al menos.\n";
		}

		return errors;
	}

	// METHOD TO VALIDATE ATTRIBUTES FOR BUSINESS PARTNER DETAILS:
	public static String validateBusinessPartnerDetails(TextArea taAddress, TextField tfCity, TextField tfProvince,
			TextField tfPostCode, TextField tfCountry) {
		String errors = "";

		if (taAddress.getText().trim().isEmpty()) {
			errors += "- Debe indicar una direcci�n.\n";
		}

		if (tfCity.getText().trim().isEmpty()) {
			errors += "- Debe indicar una ciudad.\n";
		}

		if (tfProvince.getText().trim().isEmpty()) {
			errors += "- Debe indicar una provincia.\n";
		}

		if (tfPostCode.getText().trim().isEmpty()) {
			errors += "- Debe indicar un c�digo postal.\n";
		}

		if (tfCountry.getText().trim().isEmpty()) {
			errors += "- Debe indicar un pa�s.\n";
		}

		return errors;
	}

	// END BUSINESS PARTNER
	// --------------------------------------------------------------------------------------------------------

	// COMPANY:

	public static String validateCompanyHeader(TextField tfCif, TextField tfName) {
		String errors = "";

		if (tfCif.getText().trim().isEmpty()) {
			errors += "- Debe indicar un CIF.\n";
		}

		if (tfName.getText().trim().isEmpty()) {
			errors += "- Debe indicar un nombre.\n";
		}

		return errors;
	}

	public static String validateCompanyDetails(TextArea taAddress, TextField tfCity, TextField tfProvince,
			TextField tfPostCode, TextField tfCountry) {
		String errors = "";

		if (taAddress.getText().trim().isEmpty()) {
			errors += "- Debe indicar una direcci�n.\n";
		}

		if (tfCity.getText().trim().isEmpty()) {
			errors += "- Debe indicar una ciudad.\n";
		}

		if (tfProvince.getText().trim().isEmpty()) {
			errors += "- Debe indicar una provincia.\n";
		}

		if (tfPostCode.getText().trim().isEmpty()) {
			errors += "- Debe indicar un c�digo postal.\n";
		}

		if (tfCountry.getText().trim().isEmpty()) {
			errors += "- Debe indicar un pa�s.\n";
		}

		return errors;
	}

	// END COMPANY
	// ------------------------------------------------------------------------------------------------------------

	// MEASURES:
	public static String validateMeasure(TextField tfId, TextField tfMeasure) {
		String errors = "";

		if (tfId.getText().trim().isEmpty()) {
			errors += "- Debe indicar un id.\n";
		}

		if (tfMeasure.getText().trim().isEmpty()) {
			errors += "- Debe indicar una medida.\n";
		}

		return errors;
	}

	// END MEASURE
	// ------------------------------------------------------------------------------------------------------------

	// VALIDATION SERVICES TYPES:
	public static String validatesServiceType(TextField tfName, TextArea taDescription) {
		String errors = "";

		if (tfName.getText().trim().isEmpty()) {
			errors += "- Debe indicar un nombre para el tipo de servicio.\n";
		}

		if (taDescription.getText().trim().isEmpty()) {
			errors += "- Debe indicar una descripci�n para el tipo de servicio.\n";
		}

		return errors;
	}

	// END SERVICES TYPES
	// ------------------------------------------------------------------------------------------------------------

	// VALIDATE NEW SERVICE:
	public static String validateNewService(ComboBox<String> cbServiceType, ComboBox<String> cbMeasure,
			ObservableList<String> olServiceType, ObservableList<String> olMeasure, TextField tfName,
			TextField tfUPrice, TextArea taDescription) {
		String errors = "";

		if (!IFormWindow.checkNewCbIsSelected(cbServiceType, olServiceType)) {
			errors += "- Debe indicar un tipo de servicio.\n";
		}

		if (!IFormWindow.checkNewCbIsSelected(cbMeasure, olMeasure)) {
			errors += "- Debe indicar una medida.\n";
		}

		if (tfName.getText().trim().isEmpty()) {
			errors += "- Debe indicar un nombre.\n";
		}

		if (taDescription.getText().trim().isEmpty()) {
			errors += "- Debe indicar un descripci�n.\n";
		}

		if (!IFormWindow.checkNumberTextField(tfUPrice)) {
			errors += "- Hay un problema con el precio.\n";
		}

		return errors;
	}

	// END NEW SERVICES
	// ------------------------------------------------------------------------------------------------------------

	// VALIDATE NEW SERVICE:
	public static String validateModifyService(ComboBox<String> cbServiceType, ComboBox<String> cbMeasure,
			ObservableList<String> olServiceType, ObservableList<String> olMeasure, TextField tfName,
			TextField tfUPrice, TextArea taDescription) {
		String errors = "";

		if (!IFormWindow.checkModifyCbIsSelected(cbServiceType, olServiceType)) {
			errors += "- Debe indicar un tipo de servicio.\n";
		}

		if (!IFormWindow.checkModifyCbIsSelected(cbMeasure, olMeasure)) {
			errors += "- Debe indicar una medida.\n";
		}

		if (tfName.getText().trim().isEmpty()) {
			errors += "- Debe indicar un nombre.\n";
		}

		if (taDescription.getText().trim().isEmpty()) {
			errors += "- Debe indicar un descripci�n.\n";
		}

		if (!IFormWindow.checkNumberTextField(tfUPrice)) {
			errors += "- Hay un problema con el precio.\n";
		}

		return errors;
	}

	// END NEW SERVICES
	// ------------------------------------------------------------------------------------------------------------

	// METHOD TO VALIDATE ATTRIBUTES FOR SERVICE SALE ORDER HEADER IN NEW FORM:
	public static String validateNewServicesSalesOrderHeader(ComboBox<String> cbCompany, ComboBox<String> cbCustomer,
			ObservableList<String> olCompany, ObservableList<String> olCustomer, DatePicker dpDate) {
		String errors = "";

		if (!IFormWindow.checkNewCbIsSelected(cbCompany, olCompany)) {
			errors += "- Debe indicar una compa��a.\n";
		}

		if (!IFormWindow.checkNewCbIsSelected(cbCustomer, olCustomer)) {
			errors += "- Debe indicar un cliente.\n";
		}

		if (dpDate.getValue() == null) {
			errors += "- Debe indicar una fecha para el pedido.\n";

			dpDate.setStyle("-fx-border-color: red;");
		} else {
			dpDate.setStyle("-fx-border-color: green;");
		}

		return errors;
	}

	// ------------------------------------------------------------------------

	// METHOD TO VALIDATE ATTRIBUTES FOR SERVICE SALE ORDER HEADER IN MODIFY FORM:
	public static String validateModifyServicesSalesOrderHeader(ComboBox<String> cbCompany, ComboBox<String> cbCustomer,
			ObservableList<String> olCompany, ObservableList<String> olCustomer, DatePicker dpDate) {
		String errors = "";

		if (!IFormWindow.checkModifyCbIsSelected(cbCompany, olCompany)) {
			errors += "- Debe indicar una compa��a.\n";
		}

		if (!IFormWindow.checkModifyCbIsSelected(cbCustomer, olCustomer)) {
			errors += "- Debe indicar un cliente.\n";
		}

		if (dpDate.getValue() == null) {
			errors += "- Debe indicar una fecha para el pedido.\n";

			dpDate.setStyle("-fx-border-color: red;");
		} else {
			dpDate.setStyle("-fx-border-color: blueviolet;");
		}

		return errors;
	}

	// ------------------------------------------------------------------------
	
	// SERVICE SALE ORDER:

	// METHOD TO VALIDATE ATTRIBUTES FOR SERVICE SALE ORDER LINE:
	public static String validateNewServicesSalesOrderLine(ComboBox<String> cbService, ComboBox<String> cbProfitability,
			ObservableList<String> olServices, ObservableList<String> olProfitability, TextField tfQuantity) {
		String errors = "";

		if (!IFormWindow.checkNewCbIsSelected(cbService, olServices)) {
			errors += "- Debe indicar un servicio.\n";
		}

		if (!IFormWindow.checkNewCbIsSelected(cbProfitability, olProfitability)) {
			errors += "- Debe indicar una rentabilidad.\n";
		}

		if (!IFormWindow.checkNumberTextField(tfQuantity)) {
			errors += "- Debe indicar una cantidad correcta para la l�nea de pedido.\n";

			tfQuantity.setStyle("-fx-border-color: red;");
		} else {
			tfQuantity.setStyle("-fx-border-color: green;");
		}

		return errors;
	}

	// ------------------------------------------------------------------------

	// METHOD TO VALIDATE ATTRIBUTES FOR SERVICE SALE ORDER LINE:
	public static String validateModifyServicesSalesOrderLine(ComboBox<String> cbService, ComboBox<String> cbProfitability,
			ObservableList<String> olServices, ObservableList<String> olProfitability, TextField tfQuantity) {
		String errors = "";

		if (!IFormWindow.checkModifyCbIsSelected(cbService, olServices)) {
			errors += "- Debe indicar un servicio.\n";
		}

		if (!IFormWindow.checkModifyCbIsSelected(cbProfitability, olProfitability)) {
			errors += "- Debe indicar una rentabilidad.\n";
		}

		if (!IFormWindow.checkNumberTextField(tfQuantity)) {
			errors += "- Debe indicar una cantidad correcta para la l�nea de pedido.\n";

			tfQuantity.setStyle("-fx-border-color: red;");
		} else {
			tfQuantity.setStyle("-fx-border-color: blueviolet;");
		}

		return errors;
	}

	// ------------------------------------------------------------------------
	
	// SERVICE SALE OUTPUT:

	// METHOD TO VALIDATE ATTRIBUTES FOR NEW SERVICE SALE OUTPUT HEADER:
	public static String validateNewServicesSalesOutputHeader(TextField tfOrderNumber, DatePicker dpOutputDate) {
		String errors = "";

		if (!IFormWindow.checkNumberTextField(tfOrderNumber)) {
			errors += "- Debe indicar un n�mero de pedido.\n";

			tfOrderNumber.setStyle("-fx-border-color: red;");
		} else {
			ServicesSalesOrder ssOrder = new ServicesSalesOrder();

			ssOrder.setOrderId(Integer.parseInt(tfOrderNumber.getText()));

			// System.out.println(ssOrder.checkServicesSalesOrderNumberExist());

			if (!ssOrder.checkServicesSalesOrderNumberExist()) {
				errors += "No existe un pedido con ese n�mero.";

				tfOrderNumber.setStyle("-fx-border-color: red;");
			} else {
				tfOrderNumber.setStyle("-fx-border-color: green;");
			}
		}

		if (dpOutputDate.getValue() == null) {
			errors += "- Debe indicar una fecha para la salida.\n";

			dpOutputDate.setStyle("-fx-border-color: red;");
		} else {
			dpOutputDate.setStyle("-fx-border-color: green;");
		}

		return errors;
	}

	// ------------------------------------------------------------------------

	// METHOD TO VALIDATE ATTRIBUTES FOR NEW SERVICE SALE OUTPUT LINE:
	public static String validateNewServicesSalesOutputLine(ComboBox<String> cbOrderLine, ObservableList<String> olServicesNames, TextField tfQuantity) {
		String errors = "";
		
		if (!IFormWindow.checkNewCbIsSelected(cbOrderLine, olServicesNames)) {
			errors += "- Debe indicar un servicio.\n";
		}

		if (!IFormWindow.checkNumberTextField(tfQuantity)) {
			errors += "- Debe indicar una cantidad para la l�nea.\n";

			tfQuantity.setStyle("-fx-border-color: red;");
		} else {
			tfQuantity.setStyle("-fx-border-color: green;");
		}

		return errors;
	}

	// ------------------------------------------------------------------------
	
	// METHOD TO VALIDATE ATTRIBUTES FOR NEW SERVICE SALE OUTPUT HEADER:
	public static String validateModifyServicesSalesOutputHeader(TextField tfOrderNumber, DatePicker dpOutputDate) {
		String errors = "";

		if (!IFormWindow.checkNumberTextField(tfOrderNumber)) {
			errors += "- Debe indicar un n�mero de pedido.\n";

			tfOrderNumber.setStyle("-fx-border-color: red;");
		} else {
			ServicesSalesOrder ssOrder = new ServicesSalesOrder();

			ssOrder.setOrderId(Integer.parseInt(tfOrderNumber.getText()));

			// System.out.println(ssOrder.checkServicesSalesOrderNumberExist());

			if (!ssOrder.checkServicesSalesOrderNumberExist()) {
				errors += "No existe un pedido con ese n�mero.";

				tfOrderNumber.setStyle("-fx-border-color: red;");
			} else {
				tfOrderNumber.setStyle("-fx-border-color: blueviolet;");
			}
		}

		if (dpOutputDate.getValue() == null) {
			errors += "- Debe indicar una fecha para la salida.\n";

			dpOutputDate.setStyle("-fx-border-color: red;");
		} else {
			dpOutputDate.setStyle("-fx-border-color: blueviolet;");
		}

		return errors;
	}

	// ------------------------------------------------------------------------

	// METHOD TO VALIDATE ATTRIBUTES FOR MODIFY SERVICE SALE OUTPUT LINE:
	public static String validateModifyServicesSalesOutputLine(ComboBox<String> cbOrderLine, ObservableList<String> olServicesNames, TextField tfQuantity) {
		String errors = "";
		
		if (!IFormWindow.checkModifyCbIsSelected(cbOrderLine, olServicesNames)) {
			errors += "- Debe indicar un servicio.\n";
		}

		if (!IFormWindow.checkNumberTextField(tfQuantity)) {
			errors += "- Debe indicar una cantidad para la l�nea.\n";

			tfQuantity.setStyle("-fx-border-color: red;");
		} else {
			tfQuantity.setStyle("-fx-border-color: blueviolet;");
		}

		return errors;
	}

	// ------------------------------------------------------------------------

	// ------------------------------------------------------------------------------------------------------------
}
