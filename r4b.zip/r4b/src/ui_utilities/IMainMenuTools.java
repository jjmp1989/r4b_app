package ui_utilities;

import java.io.IOException;

import javafx.event.Event;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public interface IMainMenuTools {
	public static void goSubmodule(Event e, Button button, FXMLLoader loader) {
		if (e.getSource() == button) {
			try {
				Parent root = loader.load();
				Scene s = new Scene(root);
				Stage stage = new Stage();

				stage.initStyle(StageStyle.UNDECORATED);
				stage.initStyle(StageStyle.TRANSPARENT);

				s.setFill(Color.TRANSPARENT);

				stage.setScene(s);
				stage.show();
			} catch (IOException ioe) {
				// ioe.printStackTrace();
				
				Alert alert = new Alert(Alert.AlertType.ERROR);
				alert.setHeaderText(null);
				alert.setTitle("Error");
				alert.setContentText("La vista  no pudo ser cargada. Existe un problema con el archivo fxml.");
				alert.showAndWait();
			} catch (Exception ex) {
				// ex.printStackTrace();
				
				Alert alert = new Alert(Alert.AlertType.ERROR);
				alert.setHeaderText(null);
				alert.setTitle("Error");
				alert.setContentText("La vista  no pudo ser cargada.");
				alert.showAndWait();
			}
		}
	}
}
