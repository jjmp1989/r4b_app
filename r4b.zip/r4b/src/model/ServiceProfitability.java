package model;

import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataSelector;

public class ServiceProfitability {
	// ATTRIBUTES FOR TABLE:
	private int id;
	private int percentage;

	// CONSTRUCTOR BY DEFAULT:
	public ServiceProfitability() {

	}

	// CONSTRUCTOR FOR TABLE:
	public ServiceProfitability(int id, int percentage) {
		this.id = id;
		this.percentage = percentage;
	}

	// GETTERS AND SETTERS:

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	// ----------------------------------------------------------------

	// GET PROFITABILITY PERCENTAGE:
	public ObservableList<String> getProfitabilitiesPercentages() {
		ObservableList<String> olPp = FXCollections.observableArrayList();

		try {
			/*
			 * // OPEN CONNECTION ConnectionDb connection = new ConnectionDb("localhost",
			 * "root", "Atleti1989");
			 * 
			 * connection.getC();
			 * 
			 * // STRING QUERY: String sQuery =
			 * "SELECT percentage FROM services_profitability ORDER BY percentage";
			 * 
			 * // MAKE OBJECT PreparedStatement: PreparedStatement ps =
			 * connection.getC().prepareStatement(sQuery);
			 */
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector
					.selectQuery("SELECT percentage FROM services_profitability ORDER BY percentage");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				percentage = rs.getInt(1);

				olPp.add(percentage + "");
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al obtener el porcentaje de la rentabilidad.");
		}

		// RETURN ObservableList:
		return olPp;
	}
	// ----------------------------------------------------------------------------------------

	// GET SERVICE ID:
	public int getProfitabilityIdWithPercentage() {
		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQueryWithRestrictionInt("call get_service_profitability_id_with_percentage(?)",
					getPercentage());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				id = rs.getInt(1);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� al obtener el id de la rentabilidad.");
		}

		// RETURN ObservableList:
		return id;
	}

	// ----------------------------------------------------------------------------------------
}
