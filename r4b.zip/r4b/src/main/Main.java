package main;

import controller.StartController;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;

public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane root = (BorderPane) FXMLLoader.load(getClass().getResource("/views/Start.fxml"));
			Scene scene = new Scene(root, 800, 600);
			StartController lg = new StartController();
			
			primaryStage.setScene(scene);
			//Se indica que el stage no tenga bordes
			primaryStage.initStyle( StageStyle.UNDECORATED );

			PauseTransition pause = new PauseTransition(Duration.millis(3500));
			pause.setOnFinished(event -> primaryStage.close());
			pause.play();
			
			lg.startApp(root, scene, primaryStage);

			/*
			try {
	            //STOP APP:
	            Thread.sleep(10000);
	         } catch (Exception e) {
	            System.out.println(e);
	         }
			*/
			
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}
}
