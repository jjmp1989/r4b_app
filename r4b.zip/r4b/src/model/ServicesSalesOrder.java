package model;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataInsertion;
import r4b_ddbb_management.DataSelector;
import r4b_ddbb_management.DataUpdate;

public class ServicesSalesOrder {
// ATTRIBUTES FOR TABLE services_sales_orders_header:
	private int orderId;
	private int companyId;
	private int businessPartnerId;
	private LocalDate orderDate;

	// ATTRIBUTES FOR VIEW v_services_sales_orders_header:
	private String companyName;
	private String businessPartnerName;

	// ATTRIBUTES FOR TABLE services_sales_order_lines:
	private int lineId;
	private int serviceId;
	private int profitabilityId;
	private int quantity;

	// ATTRIBUTES FOR VIEW v_services_sales_orders_lines:
	private String serviceName;
	private float uInventoryPrice;
	private int profitabilityPercentage;
	private float uSalePrice;
	private float totalPrice;

	// AFFECTED ROWS NUMBER:
	private int rows = 0;

	// CONSTRUCTOR BY DEFAULT:
	public ServicesSalesOrder() {

	}

	// CONSTRUCTOR FOR HEADER:
	public ServicesSalesOrder(int orderId, int companyId, int businessPartnerId, LocalDate orderDate) {
		super();
		this.orderId = orderId;
		this.companyId = companyId;
		this.businessPartnerId = businessPartnerId;
		this.orderDate = orderDate;
	}

	// CONSTRUCTOR FOR VIEW IN TABLE:
	public ServicesSalesOrder(int orderId, String companyName, String businessPartnerName, LocalDate orderDate) {
		super();
		this.orderId = orderId;
		this.companyName = companyName;
		this.businessPartnerName = businessPartnerName;
		this.orderDate = orderDate;
	}

	// CONSTRUCTOR TO INSERT HEADER:
	public ServicesSalesOrder(int companyId, int businessPartnerId, LocalDate orderDate) {
		this.companyId = companyId;
		this.businessPartnerId = businessPartnerId;
		this.orderDate = orderDate;
	}

	// GETTERS AND SETTERS:
	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCompanyId() {
		return companyId;
	}

	public void setCompanyId(int companyId) {
		this.companyId = companyId;
	}

	public int getBusinessPartnerId() {
		return businessPartnerId;
	}

	public void setBusinessPartnerId(int businessPartnerId) {
		this.businessPartnerId = businessPartnerId;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBusinessPartnerName() {
		return businessPartnerName;
	}

	public void setBusinessPartnerName(String businessPartnerName) {
		this.businessPartnerName = businessPartnerName;
	}

	public int getLineId() {
		return lineId;
	}

	public void setLineId(int lineId) {
		this.lineId = lineId;
	}

	public int getServiceId() {
		return serviceId;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public int getProfitabilityId() {
		return profitabilityId;
	}

	public void setProfitabilityId(int profitabilityId) {
		this.profitabilityId = profitabilityId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public float getUInventoryPrice() {
		return uInventoryPrice;
	}

	public void setUInventoryPrice(float uInventoryPrice) {
		this.uInventoryPrice = uInventoryPrice;
	}

	public int getProfitabilityPercentage() {
		return profitabilityPercentage;
	}

	public void setProfitabilityPercentage(int profitabilityPercentage) {
		this.profitabilityPercentage = profitabilityPercentage;
	}

	public float getUSalePrice() {
		return uSalePrice;
	}

	public void setUSalePrice(float uSalePrice) {
		this.uSalePrice = uSalePrice;
	}

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	// ----------------------------------------------------------------------------------------

	// SELECT services sales orders AND SHOW IN TABLE OF VIEW
	// ServicesSalesOrders.fxml:
	public ObservableList<ServicesSalesOrder> getServicesSalesOrders() {
		ObservableList<ServicesSalesOrder> obs = FXCollections.observableArrayList();

		try {
			/*
			 * // OPEN CONNECTION ConnectionDb connection = new ConnectionDb("localhost",
			 * "root", "Atleti1989");
			 * 
			 * connection.getC();
			 * 
			 * // STRING QUERY: String sQuery =
			 * "select *  from v_services_sales_orders_header";
			 * 
			 * // MAKE OBJECT PreparedStatement: PreparedStatement ps =
			 * connection.getC().prepareStatement(sQuery);
			 */
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQuery("select *  from v_services_sales_orders_header");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				orderId = rs.getInt(1);
				companyName = rs.getString(2);
				businessPartnerName = rs.getString(3);
				orderDate = rs.getDate(4).toLocalDate();

				// MAKE OBJECT ServicesSalesOrder
				ServicesSalesOrder sso = new ServicesSalesOrder(orderId, companyName, businessPartnerName, orderDate);

				obs.add(sso);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al mostrar los datos en la tabla.");
		}

		// RETURN ObservableList:
		return obs;
	}

	// ----------------------------------------------------------------------------------------
	
	// SHOW services sales order lines IN TABLE OF VIEW ServicesSalesOrderView.fxml:
	public ObservableList<ServicesSalesOrder> getServicesSalesOrderLines() {
		ObservableList<ServicesSalesOrder> obs = FXCollections.observableArrayList();

		try {
			// INSTANCE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQueryWithRestrictionInt("call get_services_sales_order_lines(?)", getOrderId());

			// RESULTS:
			while (rs.next()) {
				// INSTANCE OBJECT ServicesSalesOutput:
				ServicesSalesOrder ssOrder = new ServicesSalesOrder();
				
				// GET DATA
				ssOrder.setLineId(rs.getInt(1));
				ssOrder.setServiceName(rs.getString(2));
				ssOrder.setUInventoryPrice(rs.getFloat(3));
				ssOrder.setProfitabilityPercentage(rs.getInt(4));
				ssOrder.setUSalePrice(rs.getFloat(5));
				ssOrder.setQuantity(rs.getInt(6));
				ssOrder.setTotalPrice(rs.getFloat(7));

				obs.add(ssOrder);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();
			
			AlertMessage.showErrorAndWait("Error al mostrar los datos en la tabla.");
		}

		// RETURN ObservableList:
		return obs;
	}

	// ------------------------------------------------------------------------------------------------------------------------

	// GET STRING SERVICES SALES ORDER HEADER ID:
	public String getStringLastServicesSalesOrderId() {
		String sId = "";
		try {
			/*
			 * // OPEN CONNECTION ConnectionDb connection = new ConnectionDb("localhost",
			 * "root", "Atleti1989");
			 * 
			 * connection.getC();
			 * 
			 * // STRING QUERY: String sQuery =
			 * "SELECT MAX(id) FROM services_sales_orders_header;";
			 * 
			 * // MAKE OBJECT PreparedStatement: PreparedStatement ps =
			 * connection.getC().prepareStatement(sQuery);
			 */
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQuery("SELECT MAX(id) FROM services_sales_orders_header;");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				orderId = rs.getInt(1);
			}

			// SET STRING VALUE:
			sId = getOrderId() + "";

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al obtener el id del pedido.");
		}

		// RETURN ObservableList:
		return sId;
	}

	// -------------------------------

	// GET STRING NEXT LINE ID:
	public String getStringNextLineId() {
		String sLineId = "";
		try {
			// MAKE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQueryWithRestrictionInt("call get_next_services_sales_order_line_id(?)", getOrderId());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				lineId = rs.getInt(1);
			}

			// SET STRING VALUE:
			sLineId = getLineId() + "";

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al obtener el siguiente id de la l�nea.");
		}

		// RETURN ObservableList:
		return sLineId;
	}

	// ----------------------------------------------------------------------------------------
	
	// GET SERVICES FROM ORDER:
	public ObservableList<String> getServicesFromOrder(int orderId) {
		ObservableList<String> olService = FXCollections.observableArrayList();

		try {
			ResultSet rs = DataSelector.selectQueryWithRestrictionInt("call get_services_from_sale_order(?)", orderId);

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				serviceName = rs.getString(1);

				olService.add(serviceName);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� al obtener los servicios.");
		}

		// RETURN ObservableList:
		return olService;
	}	
	
	// --------------------------------------------------------------------------------------------------------------
	// GET LINE ID:
	public int getLineIdWithOrderIdAndServiceName() {
		try {
			// MAKE OBJECT ResultSet:
			ResultSet rs = DataSelector.selectQueryWithRestrictionIntAndString("call get_line_id_from_services_sales_order_with_service(?, ?)", orderId, serviceName);

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				lineId = rs.getInt(1);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al obtener el id del servicio.");
		}

		// RETURN lineId:
		return lineId;
	}

	// ----------------------------------------------------------------------------------------
	
	// ---------------------------------------------------------------------------------------------------

	// CHECK IF EXIST ORDER NUMBER:
	public boolean checkServicesSalesOrderNumberExist() {
		// ORDER NUMBER EXIST ---> BY DEFAULT FALSE:
		int orderNumberExist = 0;

		try {
			// OPEN CONNECTION:
			ConnectionDb connection = new ConnectionDb("localhost", "root", "Atleti1989");

			// STRING QUERY
			String sQuery = "call check_services_sales_order_number(?)";

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setInt(1, getOrderId());

			// MAKE OBJECT ResultSet:
			ResultSet rs = ps.executeQuery();

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				orderNumberExist = rs.getInt(1);
			}

			// CLOSE CONECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al chequear el combobox.");
		}

		if (orderNumberExist == 1) {
			return true;
		} else {
			return false;
		}
	}

	// ----------------------------------------------------------------------------------------

	// INSERT SERVICES SALES ORDER HEADER:
	public boolean insertServicesSalesOrdersHeader() {
		try {
			int[] integers= {getCompanyId(), getBusinessPartnerId()};
			rows = DataInsertion.insertServicesSalesHeaderData("call insert_services_sales_order_header(?, ?, ?)", integers, getOrderDate());

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage
					.showErrorAndWait("Ocurri� un error al insertar la cabecera del pedido de ventas de servicios.");
		}

		return false;
	}

	// -----------------------------------------------------------------------------------------------

	// INSERT SERVICES SALES ORDER LINE:
	public boolean insertServicesSalesOrdersLine() {
		try {
			int[] integers = {getOrderId(), getServiceId(), getProfitabilityId(), getQuantity()};
			rows = DataInsertion.insertServicesSalesLineData("call insert_services_sales_orders_lines(?, ?, ?, ?)", integers);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al insertar la l�nea del pedido de ventas de servicios.");
		}

		return false;
	}

	// -----------------------------------------------------------------------------------------------
	
	// UPDATE SERVICES SALES ORDER HEADER:
	public boolean updateServicesSalesOrderHeader() {
		try {			
			rows = DataUpdate.updateHeaderData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar la cabecera del pedido.");
		}

		return false;
	}

	// -----------------------------------------------------------------------------------------------
	
	// UPDATE SERVICES SALES ORDER LINE:
	public boolean updateServicesSalesOrderLine() {
		try {			
			rows = DataUpdate.updateDetailsOrLinesData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar la l�nea del pedido.");
		}

		return false;
	}
}
