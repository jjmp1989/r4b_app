package model;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataSelector;

public class GoodsPurchaseOrder {
	// ATTRIBUTES FOR TABLE goods_purchase_orders_header:
	private int orderId;
	private int companyHeaderId;
	private int businessPartnerId;
	private Date orderDate;
	
	// ATTRIBUTES FOR VIEW v_goods_purchase_orders_header:
	private String companyName;
	private String businessPartnerName;
	
	// ATTRIBUTES FOR TABLE goods_purchase_orders_line:
	
	
	// ATTRIBUTES FOR VIEW v_goods_purchase_orders_lines:
	
	
	public GoodsPurchaseOrder() {
		
	}

	public GoodsPurchaseOrder(int orderId, int companyHeaderId, int businessPartnerId, Date orderDate) {
		this.orderId = orderId;
		this.companyHeaderId = companyHeaderId;
		this.businessPartnerId = businessPartnerId;
		this.orderDate = orderDate;
	}

	public GoodsPurchaseOrder(int orderId, String companyName, String businessPartnerName, Date orderDate) {
		this.orderId = orderId;
		this.companyName = companyName;
		this.businessPartnerName = businessPartnerName;
		this.orderDate = orderDate;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getCompanyHeaderId() {
		return companyHeaderId;
	}

	public void setCompanyHeaderId(int companyHeaderId) {
		this.companyHeaderId = companyHeaderId;
	}

	public int getBusinessPartnerId() {
		return businessPartnerId;
	}

	public void setBusinessPartnerId(int businessPartnerId) {
		this.businessPartnerId = businessPartnerId;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBusinessPartnerName() {
		return businessPartnerName;
	}

	public void setBusinessPartnerName(String businessPartnerName) {
		this.businessPartnerName = businessPartnerName;
	}
	
	// SHOW goods purchase orders header IN TABLE OF VIEW GoodsPurchaseOrder.fxml:
	public ObservableList<GoodsPurchaseOrder> getGoodsPurchaseOrders() {
		ObservableList<GoodsPurchaseOrder> obs = FXCollections.observableArrayList();

		try {
			// MAKE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("select * from v_goods_purchase_orders_header");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				orderId = rs.getInt(1);
				companyName = rs.getString(2);
				businessPartnerName = rs.getString(3);
				orderDate = rs.getDate(4);

				// MAKE OBJECT Company
				GoodsPurchaseOrder gpo = new GoodsPurchaseOrder(orderId, companyName, businessPartnerName, orderDate);

				obs.add(gpo);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();
			
			AlertMessage.showErrorAndWait("Ocurri� un error al mostrar los datos en la tabla.");
		}
		
		// RETURN ObservableList:
		return obs;
	}
}
