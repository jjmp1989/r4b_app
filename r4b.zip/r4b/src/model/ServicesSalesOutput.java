package model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import alert_messages.AlertMessage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import r4b_ddbb_management.ConnectionDb;
import r4b_ddbb_management.DataInsertion;
import r4b_ddbb_management.DataSelector;
import r4b_ddbb_management.DataUpdate;

public class ServicesSalesOutput {
	// ATTRIBUTES FOR TABLE services_sales_output_header;
	private int outputId;
	private int orderId;
	private LocalDate outputDate;

	// ATTRIBUTES FOR VIEW v_services_sales_output_header;
	private String companyName;
	private String businessPartnerName;

	// ATTRIBUTES FOR TABLE services_sales_output_lines;
	private int outputLineId;
	private int OrderLineId;
	private int quantity;

	// ATTRIBUTES FOR VIEW v_services_sales_output_lines;
	private String serviceName;

	// AFFECTED ROWS NUMBER:
	private int rows = 0;

	// CONSTRUCTOR BY DEFAULT:
	public ServicesSalesOutput() {

	}

	// CONSTRUCTOR FOR TABLE services_sales_output_header:
	public ServicesSalesOutput(int outputId, int orderId, LocalDate outputDate) {
		super();
		this.outputId = outputId;
		this.orderId = orderId;
		this.outputDate = outputDate;
	}

	// CONSTRUCTOR FOR VIEW v_services_sales_output_header;
	public ServicesSalesOutput(int outputId, int orderId, LocalDate outputDate, String companyName,
			String businessPartnerName) {
		super();
		this.outputId = outputId;
		this.orderId = orderId;
		this.outputDate = outputDate;
		this.companyName = companyName;
		this.businessPartnerName = businessPartnerName;
	}

	// GETTERS AND SETTERS:

	public int getOutputId() {
		return outputId;
	}

	public void setOutputId(int outputId) {
		this.outputId = outputId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDate getOutputDate() {
		return outputDate;
	}

	public void setOutputDate(LocalDate outputDate) {
		this.outputDate = outputDate;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBusinessPartnerName() {
		return businessPartnerName;
	}

	public void setBusinessPartnerName(String businessPartnerName) {
		this.businessPartnerName = businessPartnerName;
	}

	public int getOutputLineId() {
		return outputLineId;
	}

	public void setOutputLineId(int outputLineId) {
		this.outputLineId = outputLineId;
	}

	public int getOrderLineId() {
		return OrderLineId;
	}

	public void setOrderLineId(int orderLineId) {
		OrderLineId = orderLineId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public int getRows() {
		return rows;
	}

	public void setRows(int rows) {
		this.rows = rows;
	}

	// ------------------------------------------------------------------------------------------------------------------------

	// SHOW services sales outputs IN TABLE OF VIEW ServicesSalesOutput.fxml:
	public ObservableList<ServicesSalesOutput> getServicesSalesOutput() {
		ObservableList<ServicesSalesOutput> obs = FXCollections.observableArrayList();

		try {
			// INSTANCE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("select * from v_services_sales_output_header");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				outputId = rs.getInt(1);
				orderId = rs.getInt(2);
				outputDate = rs.getDate(3).toLocalDate();
				companyName = rs.getString(4);
				businessPartnerName = rs.getString(5);

				// INSTANCE OBJECT ServicesSalesOutput:
				ServicesSalesOutput ssOutput = new ServicesSalesOutput(outputId, orderId, outputDate, companyName,
						businessPartnerName);

				obs.add(ssOutput);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		// RETURN ObservableList:
		return obs;
	}

	// ------------------------------------------------------------------------------------------------------------------------

	// SHOW services sales outputs lines IN TABLE OF VIEW
	// ServicesSalesOutputView.fxml:
	public ObservableList<ServicesSalesOutput> getServicesSalesOutputLines() {
		ObservableList<ServicesSalesOutput> obs = FXCollections.observableArrayList();

		try {
			// INSTANCE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQueryWithRestrictionInt("call get_services_sales_output_lines(?)",
					getOutputId());

			// RESULTS:
			while (rs.next()) {
				// INSTANCE OBJECT ServicesSalesOutput:
				ServicesSalesOutput ssOutput = new ServicesSalesOutput();

				// GET DATA
				ssOutput.setOutputLineId(rs.getInt(1));
				ssOutput.setServiceName(rs.getString(2));
				ssOutput.setQuantity(rs.getInt(3));

				obs.add(ssOutput);
			}

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			ex.printStackTrace();
		}

		// RETURN ObservableList:
		return obs;
	}

	// ------------------------------------------------------------------------------------------------------------------------

	// GET STRING SERVICES SALES ORDER HEADER ID:
	public String getStringLastServicesSalesOutputId() {
		String sId = "";
		try {
			// MAKE OBJECT ResultSet AND EXECUTE QUERY:
			ResultSet rs = DataSelector.selectQuery("SELECT MAX(id) FROM services_sales_output_header;");

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				orderId = rs.getInt(1);
			}

			// SET STRING VALUE:
			sId = getOrderId() + "";

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al obtener el id de la salida de servicios.");
		}

		// RETURN ObservableList:
		return sId;
	}

	// ----------------------------------------------------------------------------------------------------------------

	// GET STRING NEXT LINE ID:
	public String getStringNextLineId() {
		String sLineId = "";
		try {
			ResultSet rs = DataSelector.selectQueryWithRestrictionInt("call get_next_services_sales_output_line_id(?)",
					getOutputId());

			// RESULTS:
			while (rs.next()) {
				// GET DATA
				outputLineId = rs.getInt(1);
			}

			// SET STRING VALUE:
			sLineId = getOutputLineId() + "";

			// CLOSE CONNECTION:
			ConnectionDb.closeConnection();
		} catch (SQLException ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al obtener el siguiente id de la l�nea.");
		}

		// RETURN ObservableList:
		return sLineId;
	}

	// ----------------------------------------------------------------------------------------

	// INSERT SERVICE OUTPUT HEADER:
	public boolean insertServicesOutputHeader() {
		try {
			// MAKE ARRAY OF INTEGERS:
			int[] integers = { getOrderId() };

			// SET AFFECTED ROWS:
			rows = DataInsertion.insertServicesSalesHeaderData("call insert_ss_output_header(?, ?)", integers,
					getOutputDate());

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al insertar la cabecera de la salida de servicios.");
		}

		return false;
	}

	// -----------------------------------------------------------------------------------------------

	// INSERT SERVICES SALES OUTPUT LINE:
	public boolean insertServicesSalesOutputLine() {
		try {
			int[] integers = { getOutputId(), getOrderLineId(), getQuantity() };
			rows = DataInsertion.insertServicesSalesLineData("call insert_ss_output_lines(?, ?, ?)", integers);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			// ex.printStackTrace();

			AlertMessage.showErrorAndWait("Ocurri� un error al insertar la l�nea del pedido de ventas de servicios.");
		}

		return false;
	}

	// UPDATE SERVICES SALES OUTPUT HEADER:
	public int updateServicesSalesOutputHeader() {
		try {
			rows = DataUpdate.updateHeaderData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return 1;
			} else {
				return 0;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar la cabecera de la salida.");

			return -1;
		}

		// return false;
	}
	
	// UPDATE SERVICES SALES OUTPUT LINE:
	public boolean updateServicesSalesOutputLine() {
		try {			
			rows = DataUpdate.updateDetailsOrLinesData(this);

			// RETURN ROWS IF IT IS SUCCESSFUL
			if (rows > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception ex) {
			ex.printStackTrace();

			AlertMessage.showErrorAndWait("Error al modificar la l�nea de la salida.");
		}

		return false;
	}
}
