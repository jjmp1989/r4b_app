package r4b_ddbb_management;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.swing.JOptionPane;

public class DataInsertion {
	/*
	 * // PRUEBA CON ARRAY DE OBJECTOS: public static int insertData(String query,
	 * Object[] objects) { int rows = 0;
	 * 
	 * try { // OPEN CONNECTION: ConnectionDb connection = new
	 * ConnectionDb("localhost", "root", "Atleti1989");
	 * 
	 * // STRING QUERY String sQuery = query;
	 * 
	 * // MAKE OBJECT PreparedStatement: PreparedStatement ps =
	 * connection.getC().prepareStatement(sQuery);
	 * 
	 * 
	 * // SET VALUES: // ps.setString(1, getCif()); // ps.setString(2, getName());
	 * // ps.setBoolean(3, isCustomer()); // ps.setBoolean(4, isSupplier());
	 * 
	 * for (int i = 0; i < objects.length; i++) { ps.setObject(i + 1, objects[i]); }
	 * } catch (SQLException sqle) { sqle.printStackTrace(); } catch (Exception e) {
	 * e.printStackTrace(); }
	 * 
	 * return rows; }
	 * 
	 * // PRUEBA CON PAMRAMETROS VARIABLES DE OBJECTOS: public static int
	 * insertData(String query, Object ... objects) { int rows = 0;
	 * 
	 * try { // OPEN CONNECTION: ConnectionDb connection = new
	 * ConnectionDb("localhost", "root", "Atleti1989");
	 * 
	 * // STRING QUERY String sQuery = query;
	 * 
	 * // MAKE OBJECT PreparedStatement: PreparedStatement ps =
	 * connection.getC().prepareStatement(sQuery);
	 * 
	 * 
	 * // SET VALUES: // ps.setString(1, getCif()); // ps.setString(2, getName());
	 * // ps.setBoolean(3, isCustomer()); // ps.setBoolean(4, isSupplier());
	 * 
	 * for (int i = 0; i < objects.length; i++) { ps.setObject(i + 1, objects[i]); }
	 * } catch (SQLException sqle) { sqle.printStackTrace(); } catch (Exception e) {
	 * e.printStackTrace(); }
	 * 
	 * return rows; }
	 */

	// ENTERPRISE MANAGEMENT:

	// INSERT BUSINESS PARTNER HEADER:
	public static int insertBusinessPartnerHeaderData(String cif, String name, boolean customer, boolean supplier) {
		// AFFECTED ROWS:
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = "call insert_business_partner_header(?, ?, ?, ?)";

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setString(1, cif);
			ps.setString(2, name);
			ps.setBoolean(3, customer);
			ps.setBoolean(4, supplier);

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}

	// INSERT BUSINESS PARTNER DETAILS:
	public static int insertBusinessPartnerDetailsData(int id, boolean naturalPerson, String address, String city,
			String province, String postCode, String country) {
		// AFFECTED ROWS:
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = "call insert_business_partner_details(?, ?, ?, ?, ?, ?, ?)";

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setInt(1, id);
			ps.setBoolean(2, naturalPerson);
			ps.setString(3, address);
			ps.setString(4, city);
			ps.setString(5, province);
			ps.setString(6, postCode);
			ps.setString(7, country);

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}

	// INSERT COMPANY HEADER:
	public static int insertCompanyHeaderData(String cif, String name) {
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = "call insert_company_header(?, ?)";

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setString(1, cif);
			ps.setString(2, name);

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}

	// INSERT COMPANY DETAILS:
	public static int insertCompanyDetailsData(int id, boolean naturalPerson, String address, String city,
			String province, String postCode, String country) {
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = "call insert_company_details(?, ?, ?, ?, ?, ?, ?)";

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setInt(1, id);
			ps.setBoolean(2, naturalPerson);
			ps.setString(3, address);
			ps.setString(4, city);
			ps.setString(5, province);
			ps.setString(6, postCode);
			ps.setString(7, country);

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}

	public static int insertMeasureData(String measure) {
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = "call insert_measure(?)";

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setString(1, measure);

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}

	// END ENTERPRISE MANAGEMENT
	// ------------------------------------------------------------------------------

	// INVENTORY:

	// INSERT SERVICE TYPE:
	public static int insertServiceTypeData(String name, String description) {
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = "call insert_service_type(?, ?)";

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setString(1, name);
			ps.setString(2, description);

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}

	// INSERT SERVICE:
	public static int insertServiceData(int stId, int measureId, String name, String description, float uPrice) {
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = "call insert_service(?, ?, ?, ?, ?)";

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			ps.setInt(1, stId);
			ps.setInt(2, measureId);
			ps.setString(3, name);
			ps.setString(4, description);
			ps.setFloat(5, uPrice);

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}

	// END INVENTORY
	// --------------------------------------------------------------------------------------------------

	// SALES:

	// INSERT SERVICES SALES HEADER (ORDER OR OUTPUT):
	public static int insertServicesSalesHeaderData(String query, int[] integers, LocalDate orderDate) {
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = query;

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// CREATE INT TO GET POSITION:
			int position = 1;

			// SET VALUES:
			for (int i = 0; i < integers.length; i++) {
				ps.setInt(position, integers[i]);

				position++;
			}

			ps.setDate(position, Date.valueOf(orderDate));

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		// RETURN AFFECTED ROWS:
		return rows;
	}

	// INSERT SERVICES SALES LINE (ORDER OR OUTPUT):
	public static int insertServicesSalesLineData(String query, int[] integers) {
		int rows = 0;

		try {
			// OBJECT TO GET USER AND PSSW:
			DatabaseSecurity dbs = new DatabaseSecurity();
			// OPEN CONNECTION
			ConnectionDb connection = new ConnectionDb("localhost", dbs.getCredentials()[0], dbs.getCredentials()[1]);

			// STRING QUERY
			String sQuery = query;

			// MAKE OBJECT PreparedStatement:
			PreparedStatement ps = connection.getC().prepareStatement(sQuery);

			// SET VALUES:
			for (int i = 0; i < integers.length; i++) {
				ps.setInt(i + 1, integers[i]);
			}

			// RETURN NUMBER ROWS AFFECTED:
			rows = ps.executeUpdate();
		} catch (SQLException sqle) {
			// sqle.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + sqle.getErrorCode() + "\n." + sqle.getMessage(),
					"Error", 0);
		} catch (Exception e) {
			// e.printStackTrace();

			JOptionPane.showMessageDialog(null, "C�digo de error: " + e.getMessage(), "Error", 0);
		}

		// CLOSE CONECTION:
		ConnectionDb.closeConnection();

		return rows;
	}
}
